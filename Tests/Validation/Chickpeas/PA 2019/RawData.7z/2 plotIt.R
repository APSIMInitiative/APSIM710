rm(list=ls())
setwd("~/work/Projects/GRDC Pulse 2019/Chickpeas/")

# Make some plots

library(data.table)
library(dplyr)
library(ggplot2)
library(gridExtra)
library(grid)

options(stringsAsFactors = F)

# Generic function to read apsim output files. Adds factor levels if found.
read.apsim <- function(apsim.name) {
  header<-readLines(apsim.name, n=25)
  if (length(header) == 0 ) {return(NULL)}
  i<-3  # 4th line
  apsim <- read.table(apsim.name,skip=i+1,na.strings=c("NA","?"))
  names(apsim) <- unlist(strsplit(trimws(header[i]), " +"))
  
#  cat(apsim.name, " = ", ncol(apsim), "\n")
  return(cbind(filename=apsim.name, apsim))
}

capitalise <- function(x) {
  s <- strsplit(x, " ")[[1]]
  paste(toupper(substring(s, 1,1)), tolower(substring(s, 2)),
        sep="", collapse=" ")
}


df.obs<-  read.csv("Chickpea Phenology.csv")
df.obs$SimulationName<- tolower(apply(df.obs[,c("site", "Irrigation_level", "TOS", "cultivar")], 1, paste, collapse="."))
df.obs$sowDate<- as.Date(df.obs$sowDate, format = "%d/%m/%Y")
#df.obs$FloweringDAS <- df.obs$FlwDAS
#df.obs$MaturityDAS <- df.obs$MatDAS

pdf("2 plotIt.pdf", width = 7, height=6)

ggplot(df.obs) + 
  geom_boxplot(aes(x=cultivar,y=MaturityDAS, color=site)) + 
  scale_x_discrete() + theme_minimal()  + theme_minimal()

# 1 - Just the observed data. Order by median FlDAS
Z <- df.obs[!is.na(df.obs$FloweringDAS),]
m<- Z %>% group_by(cultivar) %>% summarise(fd=median(FloweringDAS))
g<-ggplot(Z) + 
  geom_boxplot(aes(x=factor(cultivar, levels=m$cultivar[order(m$fd)]),y=FloweringDAS, color=site)) + 
  labs(title="Flowering observations by cultivar", x="Cultivar") +
  scale_x_discrete() + theme_minimal()  + theme_minimal()
print(g)

g<-ggplot(Z) + 
  geom_boxplot(aes(x=factor(cultivar, levels=m$cultivar[order(m$fd)]),y=FloweringDAS)) + 
  labs(title="Flowering observations by cultivar & TOS", x="Cultivar") +
  scale_x_discrete() + facet_wrap(~TOS) + theme_minimal()
print(g)

g<-ggplot(Z) + 
  geom_boxplot(aes(x=factor(cultivar, levels=m$cultivar[order(m$fd)]),y=MaturityDAS, color=site), na.rm=T) + 
  labs(title="Maturity observations by cultivar", x="Cultivar") +
  scale_x_discrete() + theme_minimal()
print(g)

g<-ggplot(Z) + 
  geom_boxplot(aes(x=factor(cultivar, levels=m$cultivar[order(m$fd)]),y=MaturityDAS), na.rm=T) + 
  labs(title="Maturity observations by cultivar & TOS", x="Cultivar") +
  scale_x_discrete() + facet_wrap(~TOS) + theme_minimal()
print(g)


# merge in predicted 
df.pred<- do.call(rbind, lapply(list.files(pattern="^.*Harvest\\.out$"), read.apsim))
df.pred$SimulationName<- tolower(sapply(strsplit(df.pred$filename, " "), function (x) {return(x[1])}))
df.pred$TOS <- toupper(df.pred$TOS)
df.pred$site <- sapply(df.pred$site, capitalise)
df.pred$cultivar <- sapply(df.pred$cultivar, capitalise)
df.pred<- df.pred[,c("SimulationName", "site", "TOS", "cultivar", "PoddingDAS","BuddingDAS","FloweringDAS", "MaturityDAS", "biomass", "yield", "MaxLAI")]

df <- df.obs %>% left_join(df.pred[,!names(df.pred) %in% c("site", "Irrigation_level",  "TOS", "cultivar")], 
                           by=c("SimulationName"), 
                           suffix = c(".obs", ".pred"))

# Table of site x cultivar simulations. JFC this is awful.
Z <- table(df$site, df$cultivar)
rn<- rownames(Z)
Z[Z==0] <- NA
Z<-apply(Z,2,as.character)
Z[is.na(Z)]<-""
Z<-as.data.frame(Z)
rownames(Z)<- rn

# order by maturity group found above
Z<- Z[,order(m$fd)]

grid.newpage()
pushViewport(viewport(height=0.8,width=0.9))
mytheme <- gridExtra::ttheme_default( base_size = 10 )
g<- arrangeGrob(tableGrob(Z, theme = mytheme),
                top = textGrob('Locations x cultivar', gp=gpar(cex=1.5)))
grid.draw(g)

cc <- df[complete.cases(df[,c("BuddingDAS.obs", "BuddingDAS.pred")]),]
g<-ggplot(cc) + geom_point(aes(x=BuddingDAS.obs, y=BuddingDAS.pred, 
                               color=interaction(cultivar, TOS))) + 
  scale_x_continuous(limits=range(c(cc$BuddingDAS.obs, cc$BuddingDAS.pred))) +
  scale_y_continuous(limits=range(c(cc$BuddingDAS.obs, cc$BuddingDAS.pred))) +
  labs(title="Budding DAS (Greenethorpe)", x="Observed", y = "Predicted") +
  geom_abline(intercept=0, colour="grey") + theme_minimal()
print(g)

g<-ggplot(df[!is.na(df$FloweringDAS.obs),]) + geom_point(aes(x=FloweringDAS.obs, y=FloweringDAS.pred, color=site)) + 
    scale_x_continuous(limits=range(na.omit(c(df$FloweringDAS.obs, df$FloweringDAS.pred)))) +
    scale_y_continuous(limits=range(na.omit(c(df$FloweringDAS.obs, df$FloweringDAS.pred)))) +
  labs(title="Flowering DAS", x="Observed", y = "Predicted") +
  geom_abline(intercept=0, colour="grey") + theme_minimal()
print(g)

g<-ggplot(df[!is.na(df$FloweringDAS.obs),]) + geom_point(aes(x=FloweringDAS.obs, y=FloweringDAS.pred, color=cultivar)) + 
  scale_x_continuous(limits=range(na.omit(c(df$FloweringDAS.obs, df$FloweringDAS.pred)))) +
  scale_y_continuous(limits=range(na.omit(c(df$FloweringDAS.obs, df$FloweringDAS.pred)))) +
  labs(title="Flowering DAS", x="Observed", y = "Predicted") +
  geom_abline(intercept=0, colour="grey") +
  theme_minimal()
print(g)

g<-ggplot(df) + geom_point(aes(x=PoddingDAS.obs, y=PoddingDAS.pred, color=site)) + 
  scale_x_continuous(limits=range(na.omit(c(df$PoddingDAS.obs, df$PoddingDAS.pred)))) +
  scale_y_continuous(limits=range(na.omit(c(df$PoddingDAS.obs, df$PoddingDAS.pred)))) +
  labs(title="Podding DAS", x="Observed", y = "Predicted") +
  geom_abline(intercept=0, colour="grey") + theme_minimal()
print(g)

cc <- df[complete.cases(df[,c("MaturityDAS.obs", "MaturityDAS.pred")]),]
g<-ggplot(cc) + 
   geom_point(aes(x=MaturityDAS.obs, y=MaturityDAS.pred, color=TOS)) + 
  scale_x_continuous(limits=range(c(cc$MaturityDAS.obs, cc$MaturityDAS.pred))) +
  scale_y_continuous(limits=range(na.omit(cc$MaturityDAS.obs, cc$MaturityDAS.pred))) +
  labs(title="Maturity DAS (gatton)", x="Observed", y = "Predicted") +
  geom_abline(intercept=0, colour="grey") +
  theme_minimal()
print(g)


# Now all the crop data
df.obs<-  read.csv("Chickpea.csv")
df.obs<- df.obs[df.obs$cultivar=="HatTrick" | df.obs$cultivar=="Genesis" ,]
df.obs$SimulationName<- tolower(apply(df.obs[,c("site", "Irrigation_level", "TOS", "cultivar")], 1, paste, collapse="."))
df.obs$Date<- as.Date(df.obs$Date, format = "%d/%m/%Y")
df.obs$sowDate<- as.Date(df.obs$sowDate, format = "%d/%m/%Y")

df.harv<- df.obs[df.obs$Phase=="Mat",]
df.harv$biomass <- df.harv$tot_biom_m2 * 10
df.harv$yield <- df.harv$yield_per_m2 * 10

# merge in predicted 
df <- df.harv %>% left_join(df.pred[,!names(df.pred) %in% c("site", "Irrigation_level",  "TOS", "cultivar")], 
                           by=c("SimulationName"), 
                           suffix = c(".obs", ".pred"))


g1<-ggplot(df) + geom_point(aes(x=biomass.obs, y=biomass.pred, color=site), na.rm = T) + 
  scale_x_continuous(limits=range(na.omit(c(df$biomass.obs, df$biomass.pred)))) +
  scale_y_continuous(limits=range(na.omit(c(df$biomass.obs, df$biomass.pred)))) +
  labs(title="Harvest Biomass (kg/ha)", x="Observed", y = "Predicted") +
  geom_abline(intercept=0, colour="grey") + facet_wrap(~cultivar) +
  theme_minimal()

g2<-ggplot(df) + geom_point(aes(x=biomass.obs, y=biomass.pred, color=cultivar)) + 
  scale_x_continuous(limits=range(na.omit(c(df$biomass.obs, df$biomass.pred)))) +
  scale_y_continuous(limits=range(na.omit(c(df$biomass.obs, df$biomass.pred)))) +
  labs(title="Harvest Biomass (kg/ha)", x="Observed", y = "Predicted") +
  geom_abline(intercept=0, colour="grey") + facet_wrap(~site) +
  theme_minimal()
grid.arrange(g1,g2,nrow=2)
#g <- arrangeGrob(g1, g2, nrow=2)
#print(g)

g1<-ggplot(df) + geom_point(aes(x=yield.obs, y=yield.pred, color=site)) + 
  scale_x_continuous(limits=range(na.omit(c(df$yield.obs, df$yield.pred)))) +
  scale_y_continuous(limits=range(na.omit(c(df$yield.obs, df$yield.pred)))) +
  labs(title="Harvest Yield (kg/ha)", x="Observed", y = "Predicted") +
  geom_abline(intercept=0, colour="grey") + facet_wrap(~cultivar) +
  theme_minimal()

g2<-ggplot(df) + geom_point(aes(x=yield.obs, y=yield.pred, color=cultivar)) + 
  scale_x_continuous(limits=range(na.omit(c(df$yield.obs, df$yield.pred)))) +
  scale_y_continuous(limits=range(na.omit(c(df$yield.obs, df$yield.pred)))) +
  labs(title="Harvest Yield (kg/ha)", x="Observed", y = "Predicted") +
  geom_abline(intercept=0, colour="grey") + facet_wrap(~site) +
  theme_minimal()
grid.arrange(g1,g2,nrow=2)

# merge in daily predicted 
df.pred<- rbindlist( lapply(list.files(pattern="^.*Daily\\.out$"), read.apsim), fill = T)
df.pred$SimulationName<- tolower(sapply(strsplit(df.pred$filename, " "), function (x) {return(x[1])}))
df.pred$TOS <- toupper(df.pred$TOS)
df.pred$site <- sapply(df.pred$site, capitalise)
df.pred$cultivar <- sapply(df.pred$cultivar, capitalise)
df.pred$Date<- as.Date(df.pred$Date, format = "%d/%m/%Y")

#df.pred<- df.pred[,c("SimulationName", "site", "TOS", "cultivar", "FloweringDAS", "MaturityDAS", "biomass", "yield", "MaxLAI")]

df.obs$Yield <- df.obs$yield_per_m2 * 10
df.obs$Biomass <- df.obs$tot_biom_m2 * 10
df.obs$leaf_no <- df.obs$AvPlantLeaf
  
df.obs$leafGreenWt <- df.obs$greenleaf_dwt_m2
df.obs$leafSenescedWt <- df.obs$yellowleaf_dwt_m2
df.obs$leafTotalWt <- df.obs$leafGreenWt +df.obs$leafSenescedWt
df.obs$podTotalWt <- df.obs$pod_dwt_m2
df.obs$stemTotalWt <- df.obs$stem_dwt_m2

# Apsim's "pods" are just the pod walls without seed
df.pred$podTotalWt <- df.pred$podTotalWt + df.pred$grainTotalWt


df <- df.pred %>% left_join(df.obs[,!names(df.obs) %in% c("site", "Irrigation_level",  "TOS", "cultivar")], 
                            by=c("SimulationName", "Date"), 
                            suffix = c(".pred", ".obs"))

g<-ggplot(df, aes(x=DaysAfterSowing, group=SimulationName, colour= interaction(site,Irrigation_level))) + 
  geom_line(aes(y=lai.pred)) +
  geom_point(aes(y=lai.obs), na.rm = T) + 
  labs(title="LAI", x="Days After Sowing", y = "m2/m2") +
  scale_colour_discrete(name="") +
  theme_minimal()
print(g)
g<-ggplot(df[df$site=="Gatton",], aes(x=DaysAfterSowing, group=SimulationName, 
                                      colour= interaction(TOS,Irrigation_level))) + 
  geom_line(aes(y=lai.pred)) +
  geom_point(aes(y=lai.obs), na.rm = T) + 
  labs(title="LAI @ GAtton", x="Days After Sowing", y = "m2/m2") +
  scale_colour_discrete(name="") +
  theme_minimal()
print(g)


g<-ggplot(df, aes(x=DaysAfterSowing, group=SimulationName, colour= interaction(site,Irrigation_level))) + 
  geom_line(aes(y=leaf_no.pred)) +
  geom_point(aes(y=leaf_no.obs), na.rm = T) + 
  annotate("text", x=100,y=50,label="NB. Apsim = leaves per plant; obs = leaf # / main stem") +
  labs(title="Leaf number", x="Days After Sowing", y = "#/plant") +
  scale_colour_discrete(name="") +
  theme_minimal()
print(g)

g<-ggplot(df, aes(x=DaysAfterSowing, group=SimulationName, colour= interaction(site,Irrigation_level))) + 
  geom_line(aes(y=leafTotalWt.pred)) +
  geom_point(aes(y=leafTotalWt.obs), na.rm = T) + 
  labs(title="Total Leaf Weight", x="Days After Sowing", y = "g/m2") +
  scale_colour_discrete(name="") +
  theme_minimal()
print(g)

g<-ggplot(df[df$site=="Gatton" & df$Irrigation_level=="irrigated",], 
          aes(x=DaysAfterSowing, group=SimulationName, 
              colour= interaction(TOS,Irrigation_level))) + 
  geom_line(aes(y=leafTotalWt.pred)) +
  geom_point(aes(y=leafTotalWt.obs), na.rm = T) + 
  labs(title="Total Leaf Weight @ Gatton", x="Days After Sowing", y = "g/m2") +
  scale_colour_discrete(name="") +
  theme_minimal()
print(g)

g<-ggplot(df, aes(x=DaysAfterSowing, group=SimulationName, colour= interaction(site,Irrigation_level))) + 
  geom_line(aes(y=leafGreenWt.pred)) +
  geom_point(aes(y=leafGreenWt.obs), na.rm = T) + 
  labs(title="Green Leaf Weight", x="Days After Sowing", y = "g/m2") +
  scale_colour_discrete(name="") +
  theme_minimal()
print(g)

g<-ggplot(df, aes(x=DaysAfterSowing, group=SimulationName, colour= interaction(site,Irrigation_level))) + 
  geom_line(aes(y=leafSenescedWt.pred)) +
  geom_point(aes(y=leafSenescedWt.obs), na.rm = T) + 
  labs(title="Senesced Leaf Weight", x="Days After Sowing", y = "g/m2") +
  scale_colour_discrete(name="") +
  theme_minimal()

print(g)
g<-ggplot(df, aes(x=DaysAfterSowing, group=SimulationName, colour= interaction(site,Irrigation_level))) + 
  geom_line(aes(y=stemTotalWt.pred)) +
  geom_point(aes(y=stemTotalWt.obs), na.rm = T) + 
  labs(title="Stem Weight", x="Days After Sowing", y = "g/m2") +
  scale_colour_discrete(name="") +
  theme_minimal()

print(g)
g<-ggplot(df, aes(x=DaysAfterSowing, group=SimulationName, colour= interaction(site,Irrigation_level))) + 
  geom_line(aes(y=podTotalWt.pred)) +
  geom_point(aes(y=podTotalWt.obs), na.rm = T) + 
  labs(title="Pod Weight", x="Days After Sowing", y = "g/m2") +
  scale_colour_discrete(name="") +
  theme_minimal()
print(g)


# Now all the soil data
df.obs<-  read.csv("Chickpea soil water.csv")
df.obs$SimulationName<- tolower(apply(df.obs[,c("site", "Irrigation_level", "TOS", "cultivar")], 1, paste, collapse="."))
df.obs$Date<- as.Date(df.obs$Date, format = "%d/%m/%Y")
names(df.obs)[names(df.obs) %in% "sw.1."] <- "sw(1)"
names(df.obs)[names(df.obs) %in% "sw.2."] <- "sw(2)"
names(df.obs)[names(df.obs) %in% "sw.3."] <- "sw(3)"
names(df.obs)[names(df.obs) %in% "sw.4."] <- "sw(4)"
names(df.obs)[names(df.obs) %in% "sw.5."] <- "sw(5)"
names(df.obs)[names(df.obs) %in% "sw.6."] <- "sw(6)"

df <- df.pred[df.pred$site=="Gatton",] %>%
  left_join(df.obs[,!names(df.obs) %in% c("site", "Irrigation_level",  "TOS", "cultivar")], 
                            by=c("SimulationName", "Date"), 
                            suffix = c(".pred", ".obs"))

g<-ggplot(df, aes(x=Date, group=SimulationName, colour= interaction(site,Irrigation_level))) + 
  geom_line(aes(y=`sw(1).pred`)) +
  geom_point(aes(y=`sw(1).obs`), na.rm = T) + 
  labs(title="SW(1)", x="Date", y = "mm/mm") +
  scale_colour_discrete(name="") +
  theme_minimal()
print(g)

g<-ggplot(df, aes(x=Date, group=SimulationName, colour= interaction(site,Irrigation_level))) + 
  geom_line(aes(y=`sw(2).pred`)) +
  geom_point(aes(y=`sw(2).obs`), na.rm = T) + 
  labs(title="SW(2)", x="Date", y = "mm/mm") +
  scale_colour_discrete(name="") +
  theme_minimal()
print(g)

g<-ggplot(df, aes(x=Date, group=SimulationName, colour= interaction(site,Irrigation_level))) + 
  geom_line(aes(y=`sw(3).pred`)) +
  geom_point(aes(y=`sw(3).obs`), na.rm = T) + 
  labs(title="SW(3)", x="Date", y = "mm/mm") +
  scale_colour_discrete(name="") +
  theme_minimal()
print(g)

g<-ggplot(df, aes(x=Date, group=SimulationName, colour= interaction(site,Irrigation_level))) + 
  geom_line(aes(y=`sw(4).pred`)) +
  geom_point(aes(y=`sw(4).obs`), na.rm = T) + 
  labs(title="SW(4)", x="Date", y = "mm/mm") +
  scale_colour_discrete(name="") +
  theme_minimal()
print(g)

g<-ggplot(df, aes(x=Date, group=SimulationName, colour= interaction(site,Irrigation_level))) + 
  geom_line(aes(y=`sw(5).pred`)) +
  geom_point(aes(y=`sw(5).obs`), na.rm = T) + 
  labs(title="SW(5)", x="Date", y = "mm/mm") +
  scale_colour_discrete(name="") +
  theme_minimal()
print(g)

g<-ggplot(df.pred[df.pred$site=="Gatton" & df.pred$Date > as.Date("2019-08-15"),], 
          aes(x=Date, group=SimulationName, colour= interaction(Irrigation_level))) + 
  geom_line(aes(y=`stress_5`)) +
  labs(title="5 day avg stress @ Gatton", x="Date", y = "0-1") +
  scale_colour_discrete(name="") +
  theme_minimal()
print(g)

dev.off()
