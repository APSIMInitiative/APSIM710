rm(list=ls())
setwd("~/work/Projects/GRDC Pulse 2019/Chickpeas/")

library(xml2)
library(dplyr)
library(DEoptim)
options(stringsAsFactors = F)


# Generic function to read apsim output files. Adds factor levels if found.
read.apsim <- function(apsim.name) {
  header<-readLines(apsim.name, n=25)
  if (length(header) == 0 ) {return(NULL)}
  i<-3  # 4th line
  apsim <- read.table(apsim.name,skip=i+1,na.strings=c("NA","?"))
  names(apsim) <- unlist(strsplit(trimws(header[i]), " +"))
  
  return(cbind(filename=apsim.name, apsim))
}

capitalise <- function(x) {
  s <- strsplit(x, " ")[[1]]
  paste(toupper(substring(s, 1,1)), tolower(substring(s, 2)),
        sep="", collapse=" ")
}

readIt <- function(files) {
  df.pred <- do.call(rbind, lapply(files, read.apsim))
  df.pred$TOS <- toupper(df.pred$TOS)
  df.pred$site <- sapply(df.pred$site, capitalise)
  df.pred$cultivar <- ifelse(df.pred$cultivar == "genesis", "Genesis",
                          ifelse(df.pred$cultivar == "hattrick", "HatTrick"))
                                 
  df.pred <- df.pred[, c("site", "Irrigation_level", "TOS", "cultivar", paste0(what, "DAS"))]
  
  df <- df.obs %>% 
    left_join(df.pred, 
              by = c("site", "Irrigation_level", "TOS", "cultivar"), suffix = c(".obs", ".pred"))
  return(df[!is.na(df[[paste0(what, "DAS.pred")]]), ])
}

mae<- function(a, b) {
  return(sum(abs(a - b)) / length(a))
}

rmsd <- function(a, b) {
  e2<-(a - b) * (a - b)
  rmsdv <- sqrt(sum(e2)/length(e2))
  return(rmsdv)
}

# Calculate an error statistic of DAS
calcIt<-function(files) {
  df <- readIt(files)
  df<- df[complete.cases(df[,c(paste0(what, "DAS.obs"), 
                               paste0(what, "DAS.pred"))]), ]
  return(rmsd(df[[paste0(what, "DAS.obs")]], df[[paste0(what, "DAS.pred")]]))
}

# Write a temporary apsim file, run it, and return an error statistic
doit<- function( par ) {
  tmpSims <- list(); tmpOuts <- list()
  for (f in simFiles) {
    # Read the template .apsim file
    doc<-read_xml(file(f))
    
    cv <- tolower(xml_text(xml_find_all(doc,  "//ui/cultivar")))
    ivar <- 1
    for (variable in variables[[what]]) {
      if (length(unlist(strsplit(variable, "-"))) > 1) {
        if (unlist(strsplit(variable, "-"))[2] == 2) { next; }
        variable <- unlist(strsplit(variable, "-"))[1]
        value <- paste(par[ivar], par[ivar + 1])
        ivar <- ivar + 2
      } else {
        value <- par[ivar]
        ivar <- ivar + 1
      }
      nodes<-xml_find_all(doc,  paste0("//", cv, "/", variable))
      if (length(nodes) == 0) {stop(paste(cv, "/", variable, " not found"))}
      for (s in nodes) {
         xml_text(s) <- as.character(value)
      }
    }
    tmpSim <- gsub(".sim", ".temp.sim", f, fixed = T)
    write_xml(doc,  tmpSim)
    
    for (outf in xml_find_all(doc,  "//initdata/outputfile")) {
      tmpOuts[[f]] <- xml_text(outf)
      if (file.exists(tmpOuts[[f]])) {
         file.remove(tmpOuts[[f]])
      }
    }
    tmpSims[[f]] <- tmpSim
  }
  
  # Run apsim
  system2("Apsim.exe", unlist(tmpSims), stdout = F, stderr = F)
  
  errorStatistic <- calcIt(tmpOuts)
  cat(paste("w= ", what, ", par = ",  paste(par, collapse=","), ",e = ", errorStatistic, "\n"))
  return( errorStatistic )
}

# 
df.obs <-  read.csv("Chickpea Phenology.csv")
df.obs$site <- sapply(df.obs$site, capitalise)

variables<-list()
variables[["Budding"]]<-c("tt_emergence", "y_tt_end_of_juvenile-1", "y_tt_end_of_juvenile-2")
variables[["Flowering"]]<-c("y_tt_floral_initiation")
variables[["Podding"]]<-c("y_tt_flowering")
variables[["Maturity"]]<-c("y_tt_start_grain_fill-1", "y_tt_start_grain_fill-2")
 
# recreate the simfiles
for (cultivar in  unique(df.obs$cultivar)) {
#  for (what in c("Budding", "Flowering", "Podding", "Maturity")) {
  for (what in c( "Maturity")) {
    for (f in list.files(".", "^.*temp\\.sim$")) { file.remove(f) }
    sites<- unique(df.obs$site[!is.na(df.obs[,paste0(what, "DAS")])])

    if (what == "Flowering") {sites <- "Gatton"} # gatton only.
    
    system2("ApsimToSim.exe", "\"Chickpea auto.apsim\"", stderr=F)
    simFiles <- list.files(".", "^.*\\.sim$")
    simFiles <- simFiles[grepl(cultivar,simFiles) & grepl(paste(sites, collapse="|"),simFiles)]

    de <- DEoptim(doit, 
                  lower=rep(50,times=length(variables[[what]])), 
                  upper=rep(1000,times=length(variables[[what]])), 
                  control=list(NP=50 * length(variables[[what]]), 
                               itermax=50))
    
    save(de, file=paste0("Chickpea." , what, ".", cultivar, ".RData"))
    
    doc<-read_xml("Chickpea.xml")
    par<- de$optim$bestmem
    ivar <- 1
    for (variable in variables[[what]]) {
      if (length(unlist(strsplit(variable, "-"))) > 1) {
        if (unlist(strsplit(variable, "-"))[2] == 2) { next; }
        variable <- unlist(strsplit(variable, "-"))[1]
        value <- paste(par[ivar], par[ivar + 1])
        ivar <- ivar + 2
      } else {
        value <- par[ivar]
        ivar <- ivar + 1
      }
      nodes<-xml_find_all(doc,  paste0("//", tolower(cultivar), "/", variable))
      if (length(nodes) == 0) {stop(paste(tolower(cultivar), "/", variable, " not found"))}
      for (s in nodes) {
        xml_text(s) <- as.character(value)
      }
    }
    write_xml(doc,  "Chickpea.xml")
  }
}