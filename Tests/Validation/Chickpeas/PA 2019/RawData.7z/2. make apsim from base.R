rm(list=ls())
setwd("~/work/Projects/GRDC Pulse 2019/Chickpeas/")

library(xml2)

if (!file.exists("Soils.soils")) {
  download.file("https://github.com/APSIMInitiative/APSIMClassic/raw/master/UserInterface/ToolBoxes/Soils.soils", "Soils.soils")
}
soilDoc<-read_xml("Soils.soils")
baseDoc<-read_xml("base.apsim")

# Add the custom soils in base.apsim into the soil library
for (s in xml_find_all(baseDoc,  "//Soil")) {
  cat(xml_attr(s, "name"), "\n")
  xml_add_child(soilDoc, s) 
}

#soilNode <- xml_find_all(soilDoc, "//Soil")[[1]]

xmlAdd <- function(parent, name) {
  xml_add_child(parent, name)
  return(xml_child(parent, xml_length(parent)))
}

xmlSetNode <- function (parent, node) {
  xml_replace(xml_find_all(parent, paste0(".//", xml_name(node))), node)
}

xmlSetText <- function (parent, nodeName, value) {
  xml_remove(xml_find_all(parent, paste0(".//", nodeName)))
  xml_add_child(parent, nodeName, value)
}

xmlSetVec <- function (parent, nodeName, values) {
  xml_remove(xml_find_all(parent, paste0(".//", nodeName)))
  v <- xmlAdd(parent, nodeName) 
  for (value in values) {
    xml_add_child(v, ifelse(is.numeric(value), "double", "string"), value)
  }
}

getFlatVec <- function(node, childName) {
  return(as.numeric(unlist(strsplit(xml_text(xml_child(node,  childName)), " "))))
}

setFlatVec <- function(node, childName, values) {
  xml_remove(xml_find_all(node, paste0("./", childName)))
  xml_add_child(node, read_xml( paste0("<", childName, ">", paste(values, collapse=" "), "</", childName, ">")))  
}

defaults<- list()
defaults[["Soil"]] <- "Black Vertosol-Mywybilla (Bongeen No001)"
defaults[["Greenethorpe,TOS1"]] <-as.Date("30-apr-2019", format="%d-%b-%Y")
defaults[["Greenethorpe,TOS2"]] <- as.Date("21-may-2019", format="%d-%b-%Y")
defaults[["Greenethorpe,TOS3"]] <- as.Date("11-jun-2019", format="%d-%b-%Y")
defaults[["Greenethorpe,row_spacing"]] <- 250 
defaults[["Greenethorpe,sowing_density"]] <- 25 
defaults[["Greenethorpe,Soil"]] <- "Sandy loam over a sandy clay and heavy clay (Greenethorpe No691)"
defaults[["Greenethorpe,irrigated,isw"]] <- defaults[["Greenethorpe,rainfed,isw"]] <- 
  list(x=c(100,200,400,600,800,1000,1200,1400,1600), y=c(0.181, 0.204, 0.567, 0.319, 0.310, 0.283, 0.269, 0.269, 0.241))
defaults[["Greenethorpe,irrigated,isn"]] <- defaults[["Greenethorpe,rainfed,isn"]] <- 70
defaults[["Greenethorpe,metfile"]] <- "Greenethorpe.met"
defaults[["Greenethorp1,rainfed"]] <- ""
defaults[["Greenethorpe,irrigated"]] <- list(
  "21-may" = "if (TOS = 'TOS2') then \n irrigation apply amount = 15 \n endif",
  "13-aug" = "irrigation apply amount = 10",
  "14-aug" = "irrigation apply amount = 10",
  "15-aug" = "irrigation apply amount = 10",
  "26-aug" = "irrigation apply amount = 10",
  "31-aug" = "irrigation apply amount = 10",
  "03-sep" = "irrigation apply amount = 10",
  "25-sep" = "irrigation apply amount = 10",
  "30-sep" = "irrigation apply amount = 10",
  "1-oct" = "irrigation apply amount = 10")

defaults[["Gatton,TOS1"]] <- as.Date("22-May-2019", format="%d-%b-%Y")
defaults[["Gatton,TOS2"]] <- as.Date("10-Jun-2019", format="%d-%b-%Y")
defaults[["Gatton,TOS3"]] <- as.Date("25-Jun-2019" , format="%d-%b-%Y")
defaults[["Gatton,row_spacing"]] <- 250           #fixme
defaults[["Gatton,sowing_density"]] <- 25         #fixme
defaults[["Gatton,Soil"]] <- "Black Vertosol (Lawes No037) "

#vvv
#sat	0.477	0.484	0.509	0.495	0.459	0.466
#dul	0.453	0.460	0.386	0.370	0.340	0.332
#ll15	0.192	0.273	0.298	0.257	0.265	0.272
#ad	0.182	0.259	0.298	0.257	0.265	0.272
#bd	1.320	1.300	1.230	1.270	1.370	1.350

defaults[["Gatton,Soil,thickness"]] <-c(150, 150,  300,  300,  300,  300)
#defaults[["Gatton,Soil,bd"]] <-c(   1.32,   1.3, 1.23, 1.27, 1.37, 1.35)
#defaults[["Gatton,Soil,sat"]] <-c(	0.477,	0.484,	0.509,	0.495,	0.459,	0.466) # = 0.95 * (TP = 1 - bd/ 2.65)
#defaults[["Gatton,Soil,dul"]] <- c(0.453,	0.460,	0.386,	0.370,	0.340,	0.332)   # = min (sat * 0.95, max( observed))
defaults[["Gatton,Soil,bd"]] <-c(   1.25,   1.25, 1.23, 1.27, 1.37, 1.35)
defaults[["Gatton,Soil,sat"]] <-c(	0.52,	0.52 ,	0.509,	0.495,	0.459,	0.466) # = 0.95 * (TP = 1 - bd/ 2.65)
defaults[["Gatton,Soil,dul"]] <- c(0.49,	0.48,	0.386,	0.370,	0.340,	0.332)   # = min (sat * 0.95, max( observed))
defaults[["Gatton,Soil,ll15"]] <-c(0.192,	0.273,	0.298,	0.257,	0.265,	0.272	) # = min (observed)
defaults[["Gatton,Soil,ll"]]  <-c(0.192,	0.273,	0.298,	0.257,	0.265,	0.272)
defaults[["Gatton,Soil,ad"]]  <-c(0.182,	0.259,	0.298,	0.257,	0.265,	0.272) # = ll15 *  0.95
#^^^ from observed sw data. PAWC = 268mm

# These are from a month before sowing. Very dry.
#defaults[["Gatton,rainfed,isw"]] <-list(x=c(150,450,750,1050,1350), y=c(0.28, 0.28, 0.25, 0.25, 0.24))
#defaults[["Gatton,irrigated,isw"]] <-list(x=c(150,450,750,1050,1350), y=c(0.25, 0.25, 0.23, 0.20, 0.22))

# Adjusted to suit day before TOS1
defaults[["Gatton,rainfed,isw"]] <-list(x=c(150,450,750,1050,1350), y=c(0.33, 0.38, 0.32, 0.3, 0.33))
defaults[["Gatton,irrigated,isw"]] <-list(x=c(150,450,750,1050,1350), y=c(0.33, 0.38, 0.30, 0.24, 0.29))

defaults[["Gatton,rainfed,isn"]] <- list(x=c(150,450,750,1050,1350), y=c(57,13,15,19,27))
defaults[["Gatton,irrigated,isn"]] <- list(x=c(150,450,750,1050,1350), y=c(22,8, 7,11,11))
defaults[["Gatton,metfile"]] <- "Gatton.met"
#defaults[["Gatton,patchmetfile"]] <- "GilbertWS.met"
defaults[["Gatton,irrigated"]] <- list(
  "22-may" = "irrigation apply amount = 40",
  "11-jun" = "irrigation apply amount = 15",
  "26-jun" = "irrigation apply amount = 15",
  "23-jul" = "irrigation apply amount = 30",
  "6-aug" = "irrigation apply amount = 40",
  "15-aug" = "irrigation apply amount = 30",
  "4-sep" = "irrigation apply amount = 30"
)
defaults[["Gatton,rainfed"]] <- list(
  "22-may" = "irrigation apply amount = 40",
  "11-jun" = "irrigation apply amount = 15",
  "26-jun" = "irrigation apply amount = 15",
  "15-aug" = "irrigation apply amount = 15"
)

# get the defaults for a site. 
getDef <- function(site, what) {
  if (is.null(defaults[[paste0(site, ",", what)]])) {
    return(defaults[[what]])
  } 
  return(defaults[[paste0(site, ",", what)]])
}


# Fix up the initial soil water & N of a soil node
doiISoil <- function (sim, soilNode) {
  ic <- read_xml("<Sample name=\"Initial Conditions\"></Sample>")
  
  thickness <- xml_find_all(soilNode,  ".//Water/Thickness")[[1]]
  xml_add_child(ic, thickness)
  dlayer<- cumsum(as.numeric(unlist(as_list(thickness))))
  no3Node<-read_xml("<NO3/>")
  no3<- getDef(sim$site, paste0(sim$Irrigation_level, ",isn"))
  if (length(no3) > 1) {
    #cat(sim$site, ", isn=", no3$y,"\n")
    no3Fn<-approxfun(x = no3$x,
                     y = no3$y, rule=2)
    for (l in dlayer) {
      # This may not be correct if layers are different FIXME
      xml_add_child(no3Node, read_xml(paste0("<double>", no3Fn(l) , "</double>")))
    }
    
  } else {
  # NB. guessed distribution
    #cat(sim$site, ", isn=", no3,"\n")
    no3Fn<-approxfun(x = c(150, 300, 600, 900, 1200),
                   y = c(0.6, 0.2, 0.1, 0.1, 0.0), rule=2)
  for (l in dlayer) {
    # This may not be correct if layers are different FIXME
    xml_add_child(no3Node, read_xml(paste0("<double>", no3Fn(l) * no3, "</double>")))
  }
  }
  xml_add_child(ic, no3Node)
  
  nh4<-read_xml("<NH4/>")
  for (l in dlayer) {
    xml_add_child(nh4, read_xml(paste0("<double>0</double>")))
  }
  xml_add_child(ic, nh4)
  
  iswNode<-read_xml("<SW/>")
  isw<- getDef(sim$site, paste0(sim$Irrigation_level, ",isw"))
  if (length(isw) > 1) {
    #cat(sim$site, ", isw=", isw$y,"\n")
    iswFn<-approxfun(x = isw$x,
                     y = isw$y, rule=2)
    for (l in dlayer) {
      xml_add_child(iswNode, read_xml(paste0("<double>", iswFn(l), "</double>")))
    }
  } else {
    # NB. guessed distribution
    #cat(sim$site, ", isw=", isw,"\n")
    iswFn<-approxfun(x = c(150, 300, 600, 900, 1200),
                     y = c(0.6, 0.2, 0.1, 0.1, 0.0), rule=2)
    for (l in dlayer) {
      xml_add_child(iswNode, read_xml(paste0("<double>", iswFn(l) * isw, "</double>")))
    }
  }
  xml_add_child(ic, iswNode)
  xml_add_child(ic,read_xml("<NO3Units>kgha</NO3Units>"))
  xml_add_child(ic,read_xml("<NH4Units>kgha</NH4Units>"))
  xml_add_child(ic,read_xml("<SWUnits>Volumetric</SWUnits>"))
  xml_add_child(ic,read_xml("<OCUnits>Total</OCUnits>"))
  xml_add_child(ic,read_xml("<PHUnits>Water</PHUnits>"))
  return(ic)
}


# mash up the template into a single experiment simulation
doit<- function(parent, sim) {
  
  doc<-read_xml("base.apsim")
  simNode <- xml_find_all(doc, "//simulation")[[1]]
  xml_attr(simNode, "name") <- unique(sim$SimulationName)
  
  met <- xml_find_all(simNode, "//metfile")
  xmlSetText(met, "filename", getDef(sim$site, "metfile"))
  
  patch <- getDef(sim$site, "patchmetfile")
  if (length(patch) > 0) {
    xml_add_sibling(met, read_xml(paste0("<patchinput><filename>",patch, "</filename></patchinput>")))
  }
  dates<-range(sim$Clock.Today)
  clock <- xml_find_all(simNode, "//clock")
  
  # Clock starts day before the earliest TOS for this site. Important for SW initialisation
  xmlSetText(clock, "start_date", format.Date(getDef(sim$site, "TOS1") - 1, format="%d/%m/%Y"))
  xmlSetText(clock, "end_date", format.Date(getDef(sim$site, "TOS1") + 270, format="%d/%m/%Y"))
  
  # copy in a new soil 
  soil <- xml_find_all(simNode, "//simulation/area/Soil")
  xml_replace(soil, xml_find_all(soilDoc, 
                                 paste0(".//Soil[@name='", getDef(sim$site, "Soil"), "']")))
  
  thisSoil <- xml_find_all(simNode, "//simulation/area/Soil")
  
  if (length(getDef(sim$site, "Soil,bd"))) {
    waterNode <- xml_child(thisSoil,  "Water")
    # oldDlayer<- cumsum(as.numeric(unlist(strsplit(xml_text(xml_child(waterNode, "Thickness")), " "))))
    xmlSetVec(waterNode, "Thickness", getDef(sim$site, "Soil,thickness"))
    xmlSetVec(waterNode, "BD", getDef(sim$site, "Soil,bd"))
    xmlSetVec(waterNode, "AirDry", getDef(sim$site, "Soil,ad"))
    xmlSetVec(waterNode, "LL15", getDef(sim$site, "Soil,ll15"))
    xmlSetVec(waterNode, "DUL", getDef(sim$site, "Soil,dul"))
    xmlSetVec(waterNode, "SAT", getDef(sim$site, "Soil,sat"))
    
    for (n in xml_find_all(thisSoil,  ".//SoilCrop")) {
      xml_remove(n)
    }
    sc <- read_xml("<SoilCrop name=\"chickpea\" />")
    xmlSetVec(sc, "Thickness", getDef(sim$site, "Soil,thickness"))
    xmlSetVec(sc, "LL", getDef(sim$site, "Soil,ll"))
    # NB. these values are from a deep black earth in oz.
    klFn<-approxfun(x = c(150, 300, 600, 900, 1200, 1500, 1800 ),
                    y = c(0.08, 0.08, 0.08, 0.06, 0.04, 0.02, 0.02), rule=2)
    xmlSetVec(sc, "KL", sapply(cumsum(getDef(sim$site, "Soil,thickness")), klFn)) 
    xmlSetVec(sc, "XF", rep(1, length(getDef(sim$site, "Soil,thickness"))))
    xml_add_child(waterNode, sc)
  }
  
    
  # Ensure crop has a water node - it wont be in APSoil
  if (length(xml_find_all(thisSoil,  ".//SoilCrop[@name='chickpea']")) == 0) {
    src <- xml_find_all(thisSoil,  ".//SoilCrop[@name='wheat']")
    if (length(src) == 0) {
      src <- xml_find_all(thisSoil,  ".//SoilCrop[@name='sorghum']")
      xml_add_sibling(src, src)
      src <- xml_find_all(thisSoil,  ".//SoilCrop[@name='sorghum']")[2]
    } else {
      xml_add_sibling(src, src)
      src <- xml_find_all(thisSoil,  ".//SoilCrop[@name='wheat']")[2]
    }
    xml_attr(src, "name") <- "chickpea"
  }
  xml_add_child(thisSoil, doiISoil(sim, thisSoil))

    
  # Now the manager - sowing & factor levels for reporting
  uiParms <- xml_find_all(simNode, "//manager/ui")
  xmlSetText(uiParms, "sow_date", format.Date(getDef(sim$site, unique(sim$TOS)), format="%d/%m/%Y"))
  xmlSetText(uiParms, "reset_date", format.Date(getDef(sim$site, "TOS1") - 1, format="%d/%m/%Y"))
  xmlSetText(uiParms, "cultivar", unique(na.omit(sim$cultivar)))
  xmlSetText(uiParms, "density", getDef(sim$site, "sowing_density")) 
  xmlSetText(uiParms, "soil", getDef(sim$site, "Soil"))
  xmlSetText(uiParms, "Irrigation_level", sim$Irrigation_level)
  xmlSetText(uiParms, "site", sim$site)
  xmlSetText(uiParms, "tos", sim$TOS)
  
  # Irrigation schedule
  irrSched <- getDef(sim$site, sim$Irrigation_level)
  #cat(paste0(unique(sim$site), " irr = '", sim$IRR, "', sc=", length(irrSched), "\n"))
  if (!is.null(irrSched)) {
    prepareScript <-
      xml_find_all(simNode,
                   "//manager/script/event[text()='start_of_day']/../text")
    newtext <- xml_text(prepareScript)
    #if (unique(sim$IRR) == "Irr1") {cat("Boing\n")}
    for (date in names(irrSched)) {
      newtext <- paste (
        newtext,
        paste0("if (today = Date('", date, "')) then\n",
               irrSched[[date]], "\n",
               "endif\n"),
        sep = "\n"
      )
    }
    xml_text(prepareScript) <- newtext
  }
  xml_add_child(parent, simNode)
}

df <- read.csv("Chickpea Phenology.csv", stringsAsFactors  = F)
sims<- unique(df[,c("site", "Irrigation_level", "TOS", "cultivar")])
sims$SimulationName <- apply(sims[,c("site", "Irrigation_level", "TOS", "cultivar")], 1, paste, collapse=".")

# Create the .apsim output file
root <- xml_new_root( "folder" ) 
xml_attr(root, "version") <- 36
xml_attr(root, "name") <- "Simulations"

for (s in xml_find_all(baseDoc,  "//folder[@name='Plots']")) {
  xml_add_child(root, s) 
}


exps<- unique(sims$SimulationName)
for(exp in exps) {
  doit(root, sims[sims$SimulationName == exp,])
}

write_xml(root, "Chickpea auto.apsim")
