rm(list=ls())
setwd("~/work/Projects/GRDC Pulse 2019/Chickpeas/")

library(readxl)
library(data.table)
library(reshape)
library(dplyr)

# Gatton
#raw<-read_xlsx("../Data from Fernanda/19GAT_WL-Biomass predictions for modelling b.xlsx", range="A3:W77")
gatton<-read_xlsx("../Data from Fernanda/19GAT_WL-Biomass predictions for modelling.xlsx", range="A3:W77",sheet = "crop data")
for (v in names(gatton)) {
  names(gatton)[names(gatton) == v] <- gsub(" ", "_", v, fixed = T)
}

for(v in c("date_TOS1_Genesis_090", "date_TOS1_PBA_HatTrick", "date_TOS2_Genesis_090","date_TOS2_PBA_HatTrick",
           "date_TOS3_Genesis_090","date_TOS3_PBA_HatTrick")) {
  gatton[[v]] <- format.Date(gatton[[v]], format="%d/%m/%Y")
}


# Greenethorpe
gtp<-read_xlsx("../Data from Fernanda/Greenethorpe_data full - values_summary-Pete.xlsx")
gtp<- gtp[grepl("*chickpea$",gtp$crop_type),c("irrigation", "tos","variety","harvest",
                                              "doy_harvest_mean", "tot_biom_m2_mean", "avg_yield_m2_mean", "harvest_index_mean", 
                                              "pods_per_m2_mean", "seed_per_m2_mean", "kwt1000_mean", "seeds_per_pod_mean",
                                              "lai_mean", "stem_dwt_m2_mean", "greenleaf_dwt_m2_mean", "yellowleaf_dwt_m2_mean",
                                              "pod_dwt_m2_mean")]
gtp$site <- "Greenethorpe"
gtp$Date<- as.Date(paste("2019", gtp$doy_harvest_mean), format="%Y %j")
names(gtp)[names(gtp) == 'irrigation'] <- 'Irrigation_level'
names(gtp)[names(gtp) == 'tos'] <- 'TOS'
names(gtp)[names(gtp) == 'variety'] <- 'cultivar'
names(gtp)[names(gtp) == 'tot_biom_m2_mean'] <- 'tot_biom_m2'
names(gtp)[names(gtp) == 'avg_yield_m2_mean'] <- 'yield_per_m2'
names(gtp)[names(gtp) == 'harvest_index_mean'] <- 'hi'
names(gtp)[names(gtp) == 'pods_per_m2_mean'] <- 'pods_per_m2'
names(gtp)[names(gtp) == 'seed_per_m2_mean'] <- 'seed_per_m2'
names(gtp)[names(gtp) == 'lai_mean'] <- 'lai'
names(gtp)[names(gtp) == 'stem_dwt_m2_mean'] <- 'stem_dwt_m2'
names(gtp)[names(gtp) == 'greenleaf_dwt_m2_mean'] <- 'greenleaf_dwt_m2'
names(gtp)[names(gtp) == 'yellowleaf_dwt_m2_mean'] <- 'yellowleaf_dwt_m2'
names(gtp)[names(gtp) == 'pod_dwt_m2_mean'] <- 'pod_dwt_m2'
names(gtp)[names(gtp) == 'seeds_per_pod_mean'] <- 'seeds_per_pod'

gtp$Irrigation_level <- ifelse(gtp$Irrigation_level == "Dryland", "rainfed", "irrigated" )

gtp$harvest <- ifelse (gtp$harvest == "Node 7", "N07",
                       ifelse(gtp$harvest =="Node 13", "N13",
                              ifelse(gtp$harvest =="50% Flowering", "Flw",
                                     ifelse(gtp$harvest =="50% Podding", "Pod", "Mat"))))
names(gtp)[names(gtp) == 'harvest'] <- 'Phase'

gtp$cultivar <-ifelse(gtp$cultivar == "Genesis_090", "Genesis",
                      ifelse(gtp$cultivar == "PBA_HatTrick", "HatTrick",
                             ifelse(gtp$cultivar =="PBA_Monarch", "Monarch",
                                    ifelse(gtp$cultivar =="PBA_Slasher", "Slasher", "Striker")))) 
gtp$key<- paste("Greenethorpe", gtp$Irrigation_level, gtp$TOS, gtp$cultivar, sep="")



df<- expand.grid(site = "Gatton", 
                 Irrigation_level = c("irrigated", "rainfed"),
                 TOS=c("TOS1", "TOS2", "TOS3"),
                 cultivar=c("PBA_HatTrick", "Genesis_090"), 
                 Date=unique(c(gatton$date_TOS1_Genesis_090, gatton$date_TOS1_PBA_HatTrick, gatton$date_TOS2_Genesis_090,
                               gatton$date_TOS2_PBA_HatTrick, gatton$date_TOS3_Genesis_090, gatton$date_TOS3_PBA_HatTrick)), stringsAsFactors = F) 

for(v in c(unique(gatton$Variables), "Phase")) {
  df[[v]] <- NA
}

# This may win a prize for ugliness.
df$key <- apply(df[1:4],1,paste, collapse="")
for (Irrigation_level in c("irrigated", "rainfed")) {
  for(cultivar in c("PBA_HatTrick", "Genesis_090")) {
    for (TOS in c("TOS1", "TOS2", "TOS3")) {
      for(variable in unique(gatton$Variables)) {
        key<- paste("Gatton", Irrigation_level, TOS, cultivar, sep="")
        x<- as.data.frame(gatton[gatton$Irrigation_level == Irrigation_level, 
                              c( "Variables", paste0("date_",TOS,"_", cultivar), paste0("pred_",TOS, "_", cultivar), "Harvest")])
        for (i in 1:nrow(x)) {
          stopifnot(sum(df$key == key & df$Date == x[i,2]) == 1)
          df[df$key == key & df$Date == x[i,2], x[i,1]] <- x[i,3]
          if (!is.na(df[df$key == key & df$Date == x[i,2], "Phase"])) {
            if (df[df$key == key & df$Date == x[i,2], "Phase"] != x[i,4]) {
              error(paste(df[df$key == key & df$Date == x[i,2], "Phase"], "!=", x[i,4]))
            } 
          } 
          df[df$key == key & df$Date == x[i,2], "Phase"] <- x[i,4]
        }
      }
    }
  }
}
df$Date<- as.Date(df$Date, format="%d/%m/%Y")
df<- df[!apply(df[,6:(ncol(df)-1)], 1, function(x){all(is.na(x))}), ]
df$cultivar  <- ifelse(df$cultivar ==  "PBA_HatTrick", "HatTrick", "Genesis")

# All harvest data
df<- bind_rows(df, gtp)

df$sowDate = as.Date(NA)
df$sowDate[df$site=="Greenethorpe" & df$TOS=="TOS1"] <-as.Date("30-apr-2019", format="%d-%b-%Y")
df$sowDate[df$site=="Greenethorpe" & df$TOS=="TOS2"] <- as.Date("21-may-2019", format="%d-%b-%Y")
df$sowDate[df$site=="Greenethorpe" & df$TOS=="TOS3"] <- as.Date("11-jun-2019", format="%d-%b-%Y")
df$sowDate[df$site=="Gatton" & df$TOS=="TOS1"] <- as.Date("22-May-2019", format="%d-%b-%Y")
df$sowDate[df$site=="Gatton" & df$TOS=="TOS2"] <- as.Date("10-Jun-2019", format="%d-%b-%Y")
df$sowDate[df$site=="Gatton" & df$TOS=="TOS3"] <- as.Date("25-Jun-2019" , format="%d-%b-%Y")

df$Date<- format.Date(df$Date, format="%d/%m/%Y")
write.csv(df[, - which(names(df) %in% c("key", "doy_harvest_mean"))], "Chickpea.csv", row.names = F)


# Phenology
gattonGS<-read_xlsx("../Data from Fernanda/GattonGSsum.xlsx")
gattonGS$site<- "Gatton"
gattonGS$cultivar  <- ifelse(gattonGS$Variety ==  "PBA_HatTrick", "HatTrick", 
                             ifelse(gattonGS$Variety == "Genesis_090", "Genesis", NA))
gattonGS<-gattonGS[!is.na(gattonGS$cultivar),]
gattonGS$TOS<-paste0("TOS", gattonGS$TOS)
gattonGS$Irrigation_level <- gattonGS$treatment
gattonGS$sowDate<- as.Date(NA)
gattonGS$sowDate[ gattonGS$TOS=="TOS1"] <- as.Date("22-May-2019", format="%d-%b-%Y")
gattonGS$sowDate[ gattonGS$TOS=="TOS2"] <- as.Date("10-Jun-2019", format="%d-%b-%Y")
gattonGS$sowDate[ gattonGS$TOS=="TOS3"] <- as.Date("25-Jun-2019" , format="%d-%b-%Y")
gattonGS$date<- as.Date(gattonGS$date)

#gattonGS$key<- paste("Gatton", gattonGS$Irrigation_level, gattonGS$TOS, gattonGS$cultivar, sep="")
df1<-as.data.frame(dcast( as.data.table(gattonGS), site  + Irrigation_level + TOS + cultivar + sowDate ~ StartOf, value.var="date"))

for (v in (na.omit(unique(gattonGS$StartOf)))) {
  df1[[ paste0(v, "DAS") ]] <- as.numeric (df1[[v]] - df1$sowDate) 
}
df1$sowDate <- format.Date(df1$sowDate, format="%d/%m/%Y")

write.csv(df1[,c("site","Irrigation_level","TOS","cultivar","sowDate", 
                 paste0(na.omit(unique(gattonGS$StartOf)), "DAS"))], "Chickpea Phenology.csv", row.names = F)


# Harvest data
#df$Date <- as.Date(df$Date, format="%d/%m/%Y")
#df1<- as.data.frame(dcast( as.data.table(df), site  + Irrigation_level + TOS + cultivar + sowDate ~ Phase, value.var="Date"))
#for (v in (na.omit(unique(df$Phase)))) {
#  df1[[ paste0(v, "DAS") ]] <- as.numeric (df1[[v]] - df1$sowDate) 
#}
#df1$sowDate <- format.Date(df1$sowDate, format="%d/%m/%Y")
#write.csv(df1[,c("site","Irrigation_level","TOS","cultivar","sowDate", 
#                 paste0(na.omit(unique(df$Phase)), "DAS"))], "Chickpea Phenology.csv", row.names = F)

# Soil water
sw<-read_xlsx("../Data from Fernanda/19GAT_WL-Biomass predictions for modelling.xlsx", sheet = "soil water cores")

sw$TOS <- plyr::mapvalues(sw$TOS, 
                          from=c("pre-sowing", "1", "2", "3"),
                          to=c("pre-sowing", "TOS1", "TOS2", "TOS3"))
sw$cultivar <- plyr::mapvalues(sw$Variety, 
                               from=c("Genesis_090", "PBA_HatTrick"),
                               to=c("Genesis", "HatTrick"))
sw$Irrigation_level <- sw$Treatment
sw$Date <- as.Date(sw$date)

sw$depth_cm[1:10] <- rep(c(22.5, 52.5, 82.5, 112.5, 142.5), 2) + 7.5
sw$depth_cm[11:nrow(sw)] <-  sw$depth_cm[11:nrow(sw)] + 7.5
sw$layer <- plyr::mapvalues(sw$depth_cm,
                            from=c(15, 30,  60,  90, 120, 150),
                            to=c("sw(1)", "sw(2)","sw(3)","sw(4)","sw(5)","sw(6)"))

sw1<- cbind(site = "Gatton", as.data.frame(dcast( 
   as.data.table(sw), TOS + Irrigation_level +  cultivar + Date ~ layer, 
   value.var="volmoist_avg")))
sw1$Date <- format.Date(sw1$Date, format="%d/%m/%Y")

write.csv(sw1, "Chickpea soil water.csv", row.names = F)
