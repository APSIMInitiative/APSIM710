rm(list=ls())
setwd("~/work/People/Daniel/2019 Lentils/New Trials/optim/")

# run the DE optimiser

library(xml2)
library(dplyr)
library(DEoptim)
options(stringsAsFactors = F)

# recreate the simfiles
system2("ApsimToSim.exe", "\"Lentil auto.apsim\"", stderr=F)

groups<- list()
groups[["early"]] <- c("HallmarkXT", "Bolt")
groups[["mid"]] <- c("Blitz", "Jumbo2")
groups[["late"]] <- c("Nugget", "Digger", "Greenfield", "Northfield")

# Generic function to read apsim output files. Adds factor levels if found.
read.apsim <- function(apsim.name) {
  header<-readLines(apsim.name, n=25)
  if (length(header) == 0 ) {return(NULL)}
  i<-3  # 4th line
  apsim <- read.table(apsim.name,skip=i+1,na.strings=c("NA","?"))
  names(apsim) <- unlist(strsplit(trimws(header[i]), " +"))
  
  return(cbind(filename=apsim.name, apsim))
}

capitalise <- function(x) {
  s <- strsplit(x, " ")[[1]]
  paste(toupper(substring(s, 1,1)), tolower(substring(s, 2)),
        sep="", collapse=" ")
}

# read in a bunch of simfiles and return paired FlDAS values
readIt <- function(files) {
  df.pred <- do.call(rbind, lapply(files, read.apsim))
  df.pred$SimulationName <-
    sapply(strsplit(df.pred$filename, " "), function (x) {
      return(x[1])
    })
  df.pred$TOS <- toupper(df.pred$TOS)
  df.pred$site <- sapply(df.pred$site, capitalise)
  df.pred$cultivar <- sapply(df.pred$cultivar, capitalise)
  df.pred <- df.pred[, c("SimulationName", "site", "TOS", "cultivar", "FloweringDAS")]
  
  df.obs <-  read.csv("Lentil auto observed.csv")
  df.obs$cultivar <- sapply(df.obs$cultivar, capitalise)
  df.obs$site <- sapply(df.obs$site, capitalise)
  
  df <- df.obs %>% 
    left_join(df.pred, by = c("site", "TOS", "cultivar"), suffix = c(".obs", ".pred"))
  return(df[!is.na(df$FloweringDAS.pred), ])
}

mae<- function(a, b) {
  return(sum(abs(a - b)) / length(a))
}

rmsd <- function(a, b) {
  e2<-(a - b) * (a - b)
  rmsdv <- sqrt(sum(e2)/length(e2))
  return(rmsdv)
}

# Calculate an error statistic of FlDAS
calcIt<-function(files) {
  df <- readIt(files)
  #return(mae(df$FloweringDAS.obs, df$FloweringDAS.pred))
  return(rmsd(df$FloweringDAS.obs, df$FloweringDAS.pred))
}

# Write a temporary apsim file, run it, and return an error statistic
doit<- function( par ) {
  tt_ej1 <- par[1]
  tt_ej2 <- par[2] 
  tt_fi <- par[3]
  
  # Read the template .sim file
  tmpSims <- list(); tmpOuts <- list()
  for (f in simFiles) {
    doc<-read_xml(file(f))
    
    cv <- tolower(xml_text(xml_find_all(doc,  "//ui/lentil_cv")))
    
    #for (s in xml_find_all(doc,  "//x_pp_end_of_juvenile")) {
    #    xml_text(s) <- paste(pp_ej1, pp_ej2) 
    #}
    nodes<-xml_find_all(doc,  paste0("//", cv, "/y_tt_end_of_juvenile"))
    if (length(nodes) == 0) {stop(paste(cv, "y_tt_end_of_juvenile not found"))}
    for (s in nodes) {
      xml_text(s) <- paste(tt_ej1, tt_ej2) 
    }
    nodes<-xml_find_all(doc,  paste0("//", cv, "/y_tt_floral_initiation"))
    if (length(nodes) == 0) {stop(paste(cv, "y_tt_floral_initiation not found"))}
    for (s in nodes) {
      xml_text(s) <- as.character(tt_fi)
    }
    tmpSim <- gsub(".sim", ".temp.sim", f, fixed = T)
    write_xml(doc,  tmpSim)
    
    for (outf in xml_find_all(doc,  "//initdata/outputfile")) {
      tmpOuts[[f]] <- xml_text(outf)
      if (file.exists(tmpOuts[[f]])) {
         file.remove(tmpOuts[[f]])
      }
    }
    tmpSims[[f]] <- tmpSim
  }
  
  # Run apsim
  system2("Apsim.exe", unlist(tmpSims), stdout = F, stderr = F)
  
  errorStatistic <- calcIt(tmpOuts)
  cat("ej1 = ", tt_ej1, ", ej2 = ", tt_ej2, ", fi = ", tt_fi, ", e = ", errorStatistic, "\n")
  return( errorStatistic )
}

# Execution starts here. Run the DE for each group of cultivars
for (group in names(groups)) {
  cat("Group: ", group, "\n")
  for (f in list.files(".", "^.*temp\\.sim$")) { file.remove(f) }
  
  simFiles <- list.files(".", "^.*\\.sim$")
  simFiles <- simFiles[grepl(paste(groups[[group]], collapse= "|"), simFiles)]
  
  de <- DEoptim(doit, 
                lower=c(100, 30, 30), 
                upper=c(700, 400, 400), 
                control=list(NP=500, itermax=20))
  
  # Store result
  save(de, file=paste0(group,".RData"))
}
