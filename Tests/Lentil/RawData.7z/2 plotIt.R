rm(list=ls())
setwd("~/work/Projects/GRDC Pulse 2019/Lentils/Second Cut/")

# Make some plots

library(dplyr)
library(ggplot2)
library(gridExtra)
library(grid)

options(stringsAsFactors = F)

# Generic function to read apsim output files. Adds factor levels if found.
read.apsim <- function(apsim.name) {
  header<-readLines(apsim.name, n=25)
  if (length(header) == 0 ) {return(NULL)}
  i<-3  # 4th line
  apsim <- read.table(apsim.name,skip=i+1,na.strings=c("NA","?"))
  names(apsim) <- unlist(strsplit(trimws(header[i]), " +"))
  
#  cat(apsim.name, " = ", ncol(apsim), "\n")
  return(cbind(filename=apsim.name, apsim))
}

capitalise <- function(x) {
  s <- strsplit(x, " ")[[1]]
  paste(toupper(substring(s, 1,1)), tolower(substring(s, 2)),
        sep="", collapse=" ")
}

groups<- list()
groups[["early"]] <- c("HallmarkXT", "Bolt")
groups[["mid"]] <- c("Blitz", "Jumbo2", "Ace")
groups[["late"]] <- c("Nugget", "Digger", "Greenfield", "Northfield")

df.pred<- do.call(rbind, lapply(list.files(pattern="^.*Harvest\\.out$"), read.apsim))
df.pred$SimulationName<- tolower(sapply(strsplit(df.pred$filename, " "), function (x) {return(x[1])}))
df.pred$TOS <- toupper(df.pred$TOS)
df.pred$site <- sapply(df.pred$site, capitalise)
df.pred$cultivar <- sapply(df.pred$cultivar, capitalise)
df.pred$Irr <- ifelse(grepl("irr1", df.pred$SimulationName, fixed=T),  "irrigated", "rainfed")
df.pred<- df.pred[,c("SimulationName", "site", "TOS", "Irr","cultivar", "FloweringDAS", "MaturityDAS", "biomass", "yield", "MaxLAI")]

df.obs<-  read.csv("Lentil auto observed.csv")
df.obs$SimulationName<- tolower(df.obs$SimulationName)
df.obs$cultivar <- sapply(df.obs$cultivar, capitalise)
df.obs$site <- sapply(df.obs$site, capitalise)


pdf("2 plotIt.pdf", width = 7, height=6)

# 1 - Just the observed data. Order by median FlDAS
Z <- df.obs[!is.na(df.obs$FloweringDAS),]
m<- Z %>% group_by(cultivar) %>% summarise(fd=median(FloweringDAS))
g<-ggplot(Z) + 
  geom_boxplot(aes(x=factor(cultivar, levels=m$cultivar[order(m$fd)]),y=FloweringDAS)) + 
  labs(title="Flowering observations by cultivar", x="Cultivar") +
  scale_x_discrete()
print(g)
g<-ggplot(Z) + 
  geom_boxplot(aes(x=factor(cultivar, levels=m$cultivar[order(m$fd)]),y=FloweringDAS)) + 
  labs(title="Flowering observations by cultivar & TOS", x="Cultivar") +
  scale_x_discrete() + facet_wrap(~TOS)
print(g)

g<-ggplot(Z) + 
  geom_boxplot(aes(x=factor(cultivar, levels=m$cultivar[order(m$fd)]),y=MaturityDAS), na.rm=T) + 
  labs(title="Maturity observations by cultivar", x="Cultivar") +
  scale_x_discrete()
print(g)

g<-ggplot(Z) + 
  geom_boxplot(aes(x=factor(cultivar, levels=m$cultivar[order(m$fd)]),y=MaturityDAS), na.rm=T) + 
  labs(title="Maturity observations by cultivar & TOS", x="Cultivar") +
  scale_x_discrete() + facet_wrap(~TOS)
print(g)

# merge in predicted 
df <- df.obs %>% left_join(df.pred[,!names(df.pred) %in% c("site", "TOS", "cultivar")], 
                           by=c("SimulationName"), 
                           suffix = c(".obs", ".pred"))

# Table of site x cultivar simulations. JFC this is awful.
Z <- table(df$site, df$cultivar)
rn<- rownames(Z)
Z[Z==0] <- NA
Z<-apply(Z,2,as.character)
Z[is.na(Z)]<-""
Z<-as.data.frame(Z)
rownames(Z)<- rn

# order by maturity group found above
Z<- Z[,order(m$fd)]

grid.newpage()
pushViewport(viewport(height=0.8,width=0.9))
mytheme <- gridExtra::ttheme_default( base_size = 10 )
g<- arrangeGrob(tableGrob(Z, theme = mytheme),
                top = textGrob('Locations x cultivar', gp=gpar(cex=1.5)))
grid.draw(g)

#ggplot(df[df$site== "Greenethorpe2",]) + geom_point(aes(x=FloweringDAS.obs, y=FloweringDAS.pred, color=site)) + 
  #scale_x_continuous(limits=range(na.omit(c(df$FloweringDAS.obs, df$FloweringDAS.pred)))) +
  #scale_y_continuous(limits=range(na.omit(c(df$FloweringDAS.obs, df$FloweringDAS.pred)))) +
 # geom_abline(intercept=0, colour="grey") + geom_text(aes(x=FloweringDAS.obs, y=FloweringDAS.pred, 
#                                                          label=cultivar), position="nudge", angle=90)
#  theme_minimal()

g<-ggplot(df[!is.na(df$FloweringDAS.obs),]) + geom_point(aes(x=FloweringDAS.obs, y=FloweringDAS.pred, color=site)) + 
    scale_x_continuous(limits=range(na.omit(c(df$FloweringDAS.obs, df$FloweringDAS.pred)))) +
    scale_y_continuous(limits=range(na.omit(c(df$FloweringDAS.obs, df$FloweringDAS.pred)))) +
  labs(title="Flowering DAS", x="Observed", y = "Predicted") +
  geom_abline(intercept=0, colour="grey") + theme_minimal()
print(g)

g<-ggplot(df[!is.na(df$FloweringDAS.obs),]) + geom_point(aes(x=FloweringDAS.obs, y=FloweringDAS.pred, color=cultivar)) + 
  scale_x_continuous(limits=range(na.omit(c(df$FloweringDAS.obs, df$FloweringDAS.pred)))) +
  scale_y_continuous(limits=range(na.omit(c(df$FloweringDAS.obs, df$FloweringDAS.pred)))) +
  labs(title="Flowering DAS", x="Observed", y = "Predicted") +
  geom_abline(intercept=0, colour="grey") +
  theme_minimal()
print(g)

g<-ggplot(df[!is.na(df$FloweringDAS.obs),]) + geom_point(aes(x=FloweringDAS.obs, y=FloweringDAS.pred, color=TOS)) + 
  scale_x_continuous(limits=range(na.omit(c(df$FloweringDAS.obs, df$FloweringDAS.pred)))) +
  scale_y_continuous(limits=range(na.omit(c(df$FloweringDAS.obs, df$FloweringDAS.pred)))) +
  labs(title="Flowering DAS", x="Observed", y = "Predicted") +
  geom_abline(intercept=0, colour="grey") +
  theme_minimal()
print(g)

g<-ggplot(df[!is.na(df$MaturityDAS.obs),]) + geom_point(aes(x=MaturityDAS.obs, y=MaturityDAS.pred, color=cultivar)) + 
  scale_x_continuous(limits=range(na.omit(c(df$MaturityDAS.obs, df$MaturityDAS.pred)))) +
  scale_y_continuous(limits=range(na.omit(c(df$MaturityDAS.obs, df$MaturityDAS.pred)))) +
  labs(title="Maturity DAS", x="Observed", y = "Predicted") +
  geom_abline(intercept=0, colour="grey") +
  theme_minimal()
print(g)

g<-ggplot(df[!is.na(df$MaturityDAS.obs),]) + geom_point(aes(x=MaturityDAS.obs, y=MaturityDAS.pred, color=site)) + 
  scale_x_continuous(limits=range(na.omit(c(df$MaturityDAS.obs, df$MaturityDAS.pred)))) +
  scale_y_continuous(limits=range(na.omit(c(df$MaturityDAS.obs, df$MaturityDAS.pred)))) +
  labs(title="Maturity DAS", x="Observed", y = "Predicted") +
  geom_abline(intercept=0, colour="grey") +
  theme_minimal()
print(g)

g<-ggplot(df[!is.na(df$biomass.obs),]) + geom_point(aes(x=biomass.obs, y=biomass.pred, color=site)) + 
  scale_x_continuous(limits=range(na.omit(c(df$biomass.obs, df$biomass.pred)))) +
  scale_y_continuous(limits=range(na.omit(c(df$biomass.obs, df$biomass.pred)))) +
  labs(title="Biomass (kg/ha)", x="Observed", y = "Predicted") +
  geom_abline(intercept=0, colour="grey") + facet_wrap(~cultivar) +
  theme_minimal()
print(g)

g<-ggplot(df[!is.na(df$biomass.obs),]) + geom_point(aes(x=biomass.obs, y=biomass.pred, color=cultivar)) + 
  scale_x_continuous(limits=range(na.omit(c(df$biomass.obs, df$biomass.pred)))) +
  scale_y_continuous(limits=range(na.omit(c(df$biomass.obs, df$biomass.pred)))) +
  labs(title="Biomass (kg/ha)", x="Observed", y = "Predicted") +
  geom_abline(intercept=0, colour="grey") + facet_wrap(~site) +
  theme_minimal()
print(g)

g<-ggplot(df[!is.na(df$biomass.obs),]) + geom_point(aes(x=biomass.obs, y=biomass.pred, color=TOS)) + 
  scale_x_continuous(limits=range(na.omit(c(df$biomass.obs, df$biomass.pred)))) +
  scale_y_continuous(limits=range(na.omit(c(df$biomass.obs, df$biomass.pred)))) +
  labs(title="Biomass (kg/ha)", x="Observed", y = "Predicted") +
  geom_abline(intercept=0, colour="grey") + facet_wrap(~site) +
  theme_minimal()
print(g)

g<-ggplot(df[df$site=="Greenethorpe1",]) + geom_point(aes(x=biomass.obs, y=biomass.pred, 
                                                          color=interaction(TOS, Irr, sep=" "))) + 
  scale_x_continuous(limits=c(0,6000)) +
  scale_y_continuous(limits=c(0,6000)) +
  labs(title="Biomass (kg/ha)", x="Observed", y = "Predicted", color="Greenethorpe") +
  geom_abline(intercept=0, colour="grey") + facet_wrap(~cultivar) +
  theme_minimal()
print(g)

g<-ggplot(df[!is.na(df$yield.obs),]) + geom_point(aes(x=yield.obs, y=yield.pred, color=site)) + 
  scale_x_continuous(limits=range(na.omit(c(df$yield.obs, df$yield.pred)))) +
  scale_y_continuous(limits=range(na.omit(c(df$yield.obs, df$yield.pred)))) +
  labs(title="Yield (kg/ha)", x="Observed", y = "Predicted") +
  geom_abline(intercept=0, colour="grey") + facet_wrap(~cultivar) +
  theme_minimal()
print(g)

g<-ggplot(df[!is.na(df$yield.obs),]) + geom_point(aes(x=yield.obs, y=yield.pred, color=cultivar)) + 
  scale_x_continuous(limits=range(na.omit(c(df$yield.obs, df$yield.pred)))) +
  scale_y_continuous(limits=range(na.omit(c(df$yield.obs, df$yield.pred)))) +
  labs(title="Yield (kg/ha)", x="Observed", y = "Predicted") +
  geom_abline(intercept=0, colour="grey") + facet_wrap(~site) +
  theme_minimal()
print(g)

g<-ggplot(df[!is.na(df$yield.obs),]) + geom_point(aes(x=yield.obs, y=yield.pred, color=TOS)) + 
  scale_x_continuous(limits=range(na.omit(c(df$yield.obs, df$yield.pred)))) +
  scale_y_continuous(limits=range(na.omit(c(df$yield.obs, df$yield.pred)))) +
  labs(title="Yield (kg/ha)", x="Observed", y = "Predicted") +
  geom_abline(intercept=0, colour="grey") + facet_wrap(~site) +
  theme_minimal()
print(g)

g<-ggplot(df[df$site=="Greenethorpe1",]) + geom_point(aes(x=yield.obs, y=yield.pred, 
                                                          color=interaction(TOS, Irr, sep=" "))) + 
  scale_x_continuous(limits=c(0,3000)) +
  scale_y_continuous(limits=c(0,3000)) +
  labs(title="Yield (kg/ha)", x="Observed", y = "Predicted", color="Greenethorpe") +
  geom_abline(intercept=0, colour="grey") + facet_wrap(~cultivar) +
  theme_minimal()
print(g)

#ggplot(df[!is.na(df$MaxLAI.obs),]) + geom_point(aes(x=MaxLAI.obs, y=MaxLAI.pred)) + 
#  scale_x_continuous(limits=range(na.omit(c(df$MaxLAI.obs, df$MaxLAI.pred)))) +
#  scale_y_continuous(limits=range(na.omit(c(df$MaxLAI.obs, df$MaxLAI.pred)))) +
#  geom_abline(intercept=0, colour="grey") +
#  theme_minimal()

dev.off()