rm(list=ls())
setwd("~/work/People/Daniel/2019 Lentils/New Trials/First Cut/")

# Make some plots

library(dplyr)
library(ggplot2)
library(gridExtra)
library(grid)
library(data.table)

options(stringsAsFactors = F)

# Generic function to read apsim output files. Adds factor levels if found.
read.apsim <- function(apsim.name) {
  header<-readLines(apsim.name, n=25)
  if (length(header) == 0 ) {return(NULL)}
  i<-3  # 4th line
  apsim <- read.table(apsim.name,skip=i+1,na.strings=c("NA","?"))
  names(apsim) <- unlist(strsplit(trimws(header[i]), " +"))
  
  #cat(apsim.name, " = ", ncol(apsim), "\n")
  return(cbind(filename=apsim.name, apsim))
}

capitalise <- function(x) {
  s <- strsplit(x, " ")[[1]]
  paste(toupper(substring(s, 1,1)), tolower(substring(s, 2)),
        sep="", collapse=" ")
}

groups<- list()
groups[["early"]] <- c("HallmarkXT", "Bolt")
groups[["mid"]] <- c("Blitz", "Jumbo2", "Ace")
groups[["late"]] <- c("Nugget", "Digger", "Greenfield", "Northfield")

df.pred<- rbindlist( lapply(list.files(pattern="^.*Daily\\.out$"), read.apsim), fill=T)
df.pred$SimulationName<- tolower(sapply(strsplit(df.pred$filename, " "), function (x) {return(x[1])}))
df.pred$TOS <- toupper(df.pred$TOS)
df.pred$site <- sapply(df.pred$site, capitalise)
df.pred$cultivar <- sapply(df.pred$cultivar, capitalise)
df.pred$Date <- as.Date(df.pred$Date, format="%d/%m/%Y")
colnames(df.pred)[which(names(df.pred) == "esw_0_600")] <-"esw(0-600)"
colnames(df.pred)[which(names(df.pred) == "esw_100_600")] <-"esw(100-600)"

df.pred$cvgroup <- ifelse(df.pred$cultivar %in% groups[["early"]], "Early",
                            ifelse(df.pred$cultivar %in% groups[["mid"]], "Mid",
                                   ifelse(df.pred$cultivar %in% groups[["late"]], "Late", NA)))


df.obs<-  read.csv("Lentil auto observed daily.csv")
df.obs$SimulationName<- tolower(df.obs$SimulationName)
df.obs$cultivar <- sapply(df.obs$cultivar, capitalise)
df.obs$site <- sapply(df.obs$site, capitalise)
df.obs$Date <- as.Date(df.obs$Date, format="%d/%m/%Y")
df.obs$cvgroup <- ifelse(df.obs$cultivar %in% groups[["early"]], "Early",
                          ifelse(df.obs$cultivar %in% groups[["mid"]], "Mid",
                                 ifelse(df.obs$cultivar %in% groups[["late"]], "Late", NA)))


colnames(df.obs)[which(names(df.obs) == "sw.1.")] <-"sw(1)"
colnames(df.obs)[which(names(df.obs) == "sw.2.")] <-"sw(2)"
colnames(df.obs)[which(names(df.obs) == "sw.3.")] <-"sw(3)"
colnames(df.obs)[which(names(df.obs) == "sw.4.")] <-"sw(4)"
colnames(df.obs)[which(names(df.obs) == "sw.5.")] <-"sw(5)"
colnames(df.obs)[which(names(df.obs) == "sw.6.")] <-"sw(6)"
colnames(df.obs)[which(names(df.obs) == "sw.7.")] <-"sw(7)"

colnames(df.obs)[which(names(df.obs) == "esw.1.")] <-"esw(1)"
colnames(df.obs)[which(names(df.obs) == "esw.2.")] <-"esw(2)"
colnames(df.obs)[which(names(df.obs) == "esw.3.")] <-"esw(3)"
colnames(df.obs)[which(names(df.obs) == "esw.4.")] <-"esw(4)"
colnames(df.obs)[which(names(df.obs) == "esw.5.")] <-"esw(5)"
colnames(df.obs)[which(names(df.obs) == "esw.6.")] <-"esw(6)"
colnames(df.obs)[which(names(df.obs) == "esw.7.")] <-"esw(7)"

colnames(df.obs)[which(names(df.obs) == "esw_0_600")] <-"esw(0-600)"
colnames(df.obs)[which(names(df.obs) == "esw_100_600")] <-"esw(100-600)"


#table(df.obs$`sw(2)` > 0 , df.obs$site)

# merge together 
df <- df.pred %>% 
  left_join(select(df.obs, -one_of( c("site", "TOS", "cultivar", "cvgroup", "Date"))), 
     by=c("SimulationName", "DaysAfterSowing"), 
     suffix = c(".pred", ".obs")) 

pdf("2 plotIt TS.pdf", width = 7, height=6)

g<-ggplot(df) + geom_abline(intercept=0, colour="lightgrey") +
  geom_point(aes(x=`esw(100-600).obs`, y=`esw(100-600).pred`, color=site), na.rm = TRUE) + 
  labs(title="All esw (100-600)") + 
  theme_minimal()
print(g)

swSites<-unique(df$site[!is.na(df$`esw(100-600).obs`)])

# Not all sites have sw(1)
df2 <- df[!is.na(df$`sw(1).obs`),]
g<-ggplot() + 
  geom_point(data=df2, aes(x=DaysAfterSowing, color=SimulationName, y=`sw(1).obs`))  + 
  geom_line(data=df.pred[df.pred$site %in% swSites,], aes(x=DaysAfterSowing, group=SimulationName, color=SimulationName, y=`sw(1)`)) + 
  labs(y="sw(1)") +
  facet_wrap(~site)  + theme_minimal() + theme(legend.position = "none")
print(g)

# deeper layers
df2 <- df[!is.na(df$`esw(100-600).obs`),]
g<-ggplot() + 
  geom_point(data=df2, aes(x=DaysAfterSowing, color=SimulationName, y=`sw(2).obs`))  + 
  geom_line(data=df.pred[df.pred$site %in% swSites,], aes(x=DaysAfterSowing, group=SimulationName, color=SimulationName, y=`sw(2)`))+
  labs(y="sw(2)") +
  facet_wrap(~site)  + theme_minimal() + theme(legend.position = "none")
print(g)

g<-ggplot() + 
  geom_point(data=df2, aes(x=DaysAfterSowing, color=SimulationName, y=`sw(3).obs`))  + 
  geom_line(data=df.pred[df.pred$site %in% swSites,], aes(x=DaysAfterSowing, group=SimulationName, color=SimulationName, y=`sw(3)`))+
  labs(y="sw(3)") +
  facet_wrap(~site)  + theme_minimal() + theme(legend.position = "none")
print(g)


g<-ggplot() + 
  geom_point(data=df2, aes(x=DaysAfterSowing, color=SimulationName, y=`esw(100-600).obs`))  + 
  geom_line(data=df.pred[df.pred$site %in% swSites,], 
            aes(x=DaysAfterSowing, group=SimulationName, color=SimulationName, y=`esw(100-600)`))+
  labs(y="esw(100-600)") +
  facet_wrap(~site)  + theme_minimal() + theme(legend.position = "none")
print(g)


g<-ggplot(df) + 
  geom_point(aes(x=DaysAfterSowing, color=cvgroup, y=lai.obs), na.rm=T)  + 
  geom_line(aes(x=DaysAfterSowing, group=SimulationName, color=cvgroup, y=lai.pred))  +
  labs(y="LAI") +
  facet_wrap(~site)  + theme_minimal() + theme(legend.position = "none")

# Biomass & yield
df2 <- df[! df$site %in% c("Beulah", "Birchip", "Gatton", "Greenethorpe2", "Horsham" ),]
g<-ggplot(df2) + 
  geom_point(aes(x=DaysAfterSowing, color=cvgroup, y=AboveGround.Wt.obs), na.rm=T)  + 
  geom_line(aes(x=DaysAfterSowing, group=SimulationName, color=cvgroup, y=AboveGround.Wt.pred))  +
  labs(y="Biomass Wt") +
  facet_wrap(~site)  + theme_minimal() + theme(legend.position = "none")
print(g)

df2 <- df[! df$site %in% c("Beulah", "Birchip","Caragabal", "Emerald",  "Gatton", "Greenethorpe2", "Horsham", "Mildura", "Millmerran" ),]
g<-ggplot(df2) + 
  geom_point(aes(x=DaysAfterSowing, color=cvgroup, y=GrainWt.obs))  + 
  geom_line(aes(x=DaysAfterSowing, group=SimulationName, color=cvgroup, y=GrainWt.pred))  +
  labs(y="Grain Wt") +
  facet_wrap(~site)  + theme_minimal() + theme(legend.position = "none")
print(g)


dev.off()