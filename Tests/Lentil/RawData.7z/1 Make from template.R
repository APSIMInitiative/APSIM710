rm(list=ls())
library(readxl)
library(xml2)
library(dplyr)

# Read the observed data and construct an apsim file with simulations from 2 sources:
# xlsx file is from liz meier
# csv data is from DR

# this writes out simulations to "Lentil auto.apsim", and obs data in "Lentil auto observed.csv"

# >>>the experimental design (sowdates etc) is in the defaults table below<<<


setwd("~/work/People/Daniel/2019 Lentils/New Trials/First Cut/")

if (!file.exists("Soils.soils")) {
  download.file("https://github.com/APSIMInitiative/APSIMClassic/raw/master/UserInterface/ToolBoxes/Soils.soils", "Soils.soils")
}
soilDoc<-read_xml("Soils.soils")
baseDoc<-read_xml("base.apsim")

# Add the custom soils in base.apsim into the soil library
for (s in xml_find_all(baseDoc,  "//Soil")) {
  cat(xml_attr(s, "name"), "\n")
   xml_add_child(soilDoc, s) 
}

#soilNode <- xml_find_all(soilDoc, "//Soil")[[1]]

xmlAdd <- function(parent, name) {
  xml_add_child(parent, name)
  return(xml_child(parent, xml_length(parent)))
}

xmlSetNode <- function (parent, node) {
  xml_replace(xml_find_all(parent, paste0(".//", xml_name(node))), node)
}

xmlSetText <- function (parent, nodeName, value) {
  xml_remove(xml_find_all(parent, paste0(".//", nodeName)))
  xml_add_child(parent, nodeName, value)
}

xmlSetVec <- function (parent, nodeName, values) {
  xml_remove(xml_find_all(parent, paste0(".//", nodeName)))
  v <- xmlAdd(parent, nodeName) 
  for (value in values) {
    xml_add_child(v, ifelse(is.numeric(value), "double", "string"), value)
  }
}

getTOS <- function(x) {
  return(paste0("TOS", substr(strsplit(x, "TOS")[[1]][2], 1,1)))
}
getIRR <- function(x) {
  y <- strsplit(x, "Irr")[[1]][2]
  return(ifelse(!is.na(y), paste0("Irr", substr(y, 1,1)), ""))
}
getPop <- function(x) {
  y <- strsplit(x, "Pop")[[1]][2]
  return(ifelse(!is.na(y), y, ""))
}

# Data from Liz Meier
ts <- read_xlsx("./Observed for daniel.xlsx", sheet=2)
ts$site <- ifelse(grepl("^Emerald.*", ts$SimulationName ), "Emerald",
                  ifelse(grepl("^DR_2001Dooen.*", ts$SimulationName ), "Dooen",
                         ifelse(grepl("^Mildura.*", ts$SimulationName ), "Mildura",
                                ifelse(grepl("^Caragabal.*", ts$SimulationName ), "Caragabal",
                                       ifelse(grepl("^Greenethorpe19.*", ts$SimulationName ), "Greenethorpe1",
                                              ifelse(grepl("^GreenethorpePhen.*", ts$SimulationName ), "Greenethorpe2",
                                                     ifelse(grepl("^Gatton.*", ts$SimulationName ), "Gatton",
                                                            ifelse(grepl("^Walgett.*", ts$SimulationName ), "Walgett","Millmerran"))))))))
ts$SimulationName <- gsub("Dry", "Irr0", ts$SimulationName, fixed = T)
ts$SimulationName <- gsub("Wet", "Irr1", ts$SimulationName, fixed = T)
ts$SimulationName <- gsub("DR_2001Dooen", "Dooen01TOS1CvDigger", ts$SimulationName, fixed = T)

ts$TOS <- sapply(ts$SimulationName, getTOS)
ts$Pop <- sapply(ts$SimulationName, getPop)
ts$IRR <- sapply(ts$SimulationName, getIRR)
ts$Clock.Today <- format.POSIXct(ts$Clock.Today, format="%d/%m/%Y")


harv<-read_xlsx("./Observed for daniel.xlsx")
harv$SimulationName <- gsub("Dry", "Irr0", harv$SimulationName, fixed = T)
harv$SimulationName <- gsub("Wet", "Irr1", harv$SimulationName, fixed = T)
harv$SimulationName <- gsub("DR_2001Dooen", "Dooen01TOS1CvDigger", harv$SimulationName, fixed = T)

harv$site <- ifelse(grepl("^Emerald.*", harv$SimulationName ), "Emerald",
                  ifelse(grepl("^Dooen.*", harv$SimulationName ), "Dooen",
                         ifelse(grepl("^Mildura.*", harv$SimulationName ), "Mildura",
                                ifelse(grepl("^Caragabal.*", harv$SimulationName ), "Caragabal",
                                       ifelse(grepl("^Greenethorpe19.*", harv$SimulationName ), "Greenethorpe1",
                                              ifelse(grepl("^GreenethorpePhen.*", harv$SimulationName ), "Greenethorpe2",
                                                     ifelse(grepl("^Gatton.*", harv$SimulationName ), "Gatton",
                                                            ifelse(grepl("^Walgett.*", harv$SimulationName ), "Walgett","Millmerran"))))))))


harv$Clock.Today<- suppressWarnings(as.numeric(harv$Clock.Today))
harv$Clock.Today<- as.Date(harv$Clock.Today, origin = "1899-12-30")
harv$TOS <- sapply(harv$SimulationName, getTOS)
harv$IRR <- sapply(harv$SimulationName, getIRR)
harv$Pop <- sapply(harv$SimulationName, getPop)

# Defaults 
defaults<- list()
defaults[["Soil"]] <- "Black Vertosol-Mywybilla (Bongeen No001)"
#defaults[["sowing_density"]] <- "120" 
#defaults[["Operations"]] <- ""

defaults[["Emerald,TOS1"]] <- as.Date("10-May-2019", format="%d-%b-%Y")
defaults[["Emerald,TOS2"]] <- as.Date("3-jun-2019", format="%d-%b-%Y")
defaults[["Emerald,TOS3"]] <- as.Date("27-jun-2019", format="%d-%b-%Y")
defaults[["Emerald,row_spacing"]] <- 500 
defaults[["Emerald,sowing_density"]] <- 120
defaults[["Emerald,Soil"]] <- "Vertosol No7 (PAWC-204 No519-Generic)"
defaults[["Emerald,isw"]] <- c(0.326, 0.328, 0.345, 0.360, 0.359, 0.326, 0.326)
defaults[["Emerald,isn"]] <- 35   #kg/ha tot
defaults[["Emerald,metfile"]] <- "Emerald2019Combo.met"

defaults[["Dooen,TOS1"]] <- as.Date("28-Jun-2001", format="%d-%b-%Y")
defaults[["Dooen,row_spacing"]] <- 230 
defaults[["Dooen,sowing_density"]] <- 230 
defaults[["Dooen,Soil"]] <- "dooen"
defaults[["Dooen,isw"]] <- c( 0.310, 0.240, 0.210, 0.220, 0.245, 0.240, 0.257)
defaults[["Dooen,isn"]] <- 35
defaults[["Dooen,metfile"]] <- "horsham.met"
defaults[["Dooen,Irr1"]] <- list(
  "10-aug" = "irrigation apply amount = 45",
  "22-sep" = "irrigation apply amount = 45")
  
defaults[["Mildura,TOS1"]] <- as.Date("1-May-2019", format="%d-%b-%Y")
defaults[["Mildura,TOS2"]] <- as.Date("18-May-2019", format="%d-%b-%Y")
defaults[["Mildura,TOS3"]] <- as.Date("7-June-2019", format="%d-%b-%Y")
defaults[["Mildura,row_spacing"]] <- 250 
defaults[["Mildura,sowing_density"]] <- 110 
defaults[["Mildura,Soil"]] <- "Sandy Loam (Kerribee No359)"
defaults[["Mildura,isw"]] <- c(0.105, 0.149, 0.225, 0.257, 0.255, 0.255, 0.255)
defaults[["Mildura,isn"]] <- 35
defaults[["Mildura,metfile"]] <- "MildurahPO.met"

defaults[["Caragabal,TOS1"]] <- as.Date('8-May-2019', format="%d-%b-%Y")
defaults[["Caragabal,TOS2"]] <- as.Date('17-Jun-2019', format="%d-%b-%Y")
defaults[["Caragabal,row_spacing"]] <- 230 
defaults[["Caragabal,sowing_density"]] <- 110 
defaults[["Caragabal,Soil"]] <- "Vertosol No7 (PAWC-204 No519-Generic)"
defaults[["Caragabal,isw"]] <- c( 0.234, 0.291, 0.279, 0.290, 0.322, 0.335, 0.327)
defaults[["Caragabal,isn"]] <- 35
defaults[["Caragabal,metfile"]] <- "CaragabalPO.met"

defaults[["Greenethorpe1,TOS1"]] <-as.Date("30-apr-2019", format="%d-%b-%Y")
defaults[["Greenethorpe1,TOS2"]] <- as.Date("21-may-2019", format="%d-%b-%Y")
defaults[["Greenethorpe1,TOS3"]] <- as.Date("12-jun-2019", format="%d-%b-%Y")
defaults[["Greenethorpe1,row_spacing"]] <- 230 
defaults[["Greenethorpe1,sowing_density"]] <- 120 
defaults[["Greenethorpe1,Soil"]] <- "Greenethorpe_soil_2015"
defaults[["Greenethorpe1,isw"]] <- c(0.181, 0.204, 0.567, 0.319, 0.310, 0.283, 0.269, 0.269, 0.241)
defaults[["Greenethorpe1,isn"]] <- 70
defaults[["Greenethorpe1,metfile"]] <- "GreenethorpeSILO.met"
#defaults[["Greenethorpe1,Irr0"]] <- ""
defaults[["Greenethorpe1,Irr1"]] <- list(
  "21-may" = "if (TOS = 'TOS2') then \n irrigation apply amount = 15 \n endif",
  "13-aug" = "irrigation apply amount = 10",
  "14-aug" = "irrigation apply amount = 10",
  "15-aug" = "irrigation apply amount = 10",
  "26-aug" = "irrigation apply amount = 10",
  "31-aug" = "irrigation apply amount = 10",
  "03-sep" = "irrigation apply amount = 10",
  "25-sep" = "irrigation apply amount = 10",
  "30-sep" = "irrigation apply amount = 10",
  "1-oct" = "irrigation apply amount = 10")

#
#Greenethorpe phenology trial:
#•all treatments are irrigated - "JW: For greenethorpe simulate unlimited. We tried to keep it unlimited but there would have been some stress no measure of water just applied when ever we were out there." 
#•they use different TOS to the other Greenethorpe trial so will be simulated separately 
#•there are only 2 TOS for the phenology trial at Greenethorpe 
#•only treatments without lights used 
#•phenology measurements up until the time of flowering only are recorded 
defaults[["Greenethorpe2,TOS1"]] <-as.Date("18-apr-2019", format="%d-%b-%Y")
defaults[["Greenethorpe2,TOS2"]] <- as.Date("21-may-2019", format="%d-%b-%Y")
defaults[["Greenethorpe2,row_spacing"]] <- 230 
defaults[["Greenethorpe2,sowing_density"]] <- 120 
defaults[["Greenethorpe2,Soil"]] <- "Greenethorpe_soil_2015"
defaults[["Greenethorpe2,isw"]] <- c(0.181, 0.204, 0.567, 0.319, 0.310, 0.283, 0.269, 0.269, 0.241)
defaults[["Greenethorpe2,isn"]] <- 70
defaults[["Greenethorpe2,metfile"]] <- "GreenethorpeSILO.met"

defaults[["Gatton,TOS1"]] <- as.Date("10-May-2019", format="%d-%b-%Y")
defaults[["Gatton,TOS2"]] <- as.Date("7-Jun-2019", format="%d-%b-%Y")
defaults[["Gatton,TOS3"]] <- as.Date("19-Jul-2019" , format="%d-%b-%Y")
defaults[["Gatton,row_spacing"]] <- 230 
defaults[["Gatton,sowing_density"]] <- 120 
defaults[["Gatton,Soil"]] <- "Vertosol No2 (PAWC-269 No514-Generic)"
defaults[["Gatton,isw"]] <- c(0.519, 0.508, 0.501, 0.415, 0.295, 0.295, 0.295) # 50% filled from top
defaults[["Gatton,isn"]] <- 70
defaults[["Gatton,metfile"]] <- "Gatton.met"
defaults[["Gatton,patchmetfile"]] <- "GilbertWS.met"
defaults[["Gatton,Operations"]] <- ""

defaults[["Walgett,TOS1"]] <- as.Date("21-May-2019", format="%d-%b-%Y")
defaults[["Walgett,TOS2"]] <- as.Date("9-Jun-2019", format="%d-%b-%Y")
defaults[["Walgett,TOS3"]] <- as.Date("28-Jun-2019", format="%d-%b-%Y")
defaults[["Walgett,row_spacing"]] <- 375 
defaults[["Walgett,Soil"]] <- "Vertosol No11 (PAWC-136 No523-Generic)"
defaults[["Walgett,isw"]] <- c(0.199, 0.282, 0.304, 0.303, 0.297, 0.297, 0.297)
defaults[["Walgett,isn"]] <- 35
defaults[["Walgett,metfile"]] <- "Walgett.met"

defaults[["Millmerran,TOS1"]] <- as.Date("15-Jun-2019", format="%d-%b-%Y")
defaults[["Millmerran,TOS2"]] <- as.Date("2-Jul-2019", format="%d-%b-%Y")
defaults[["Millmerran,TOS3"]] <- as.Date("15-Jul-2019", format="%d-%b-%Y")
defaults[["Millmerran,row_spacing"]] <- 300 
defaults[["Millmerran,sowing_density"]] <- 52 
defaults[["Millmerran,Soil"]] <- "Vertosol No11 (PAWC-136 No523-Generic)"
defaults[["Millmerran,isw"]] <- c( 0.199, 0.282, 0.304, 0.303, 0.297, 0.297, 0.297)
defaults[["Millmerran,isn"]] <- 35   #kg/ha tot
defaults[["Millmerran,metfile"]] <- "Millmerran.met"

# get the defaults for a site. 
getDef <- function(site, what) {
  if (is.null(defaults[[paste0(site, ",", what)]])) {
    return(defaults[[what]])
  } 
  return(defaults[[paste0(site, ",", what)]])
}


# Fix up the initial soil water & N of a soil node
doiISoil <- function (site, soilNode) {
  ic <- read_xml("<Sample name=\"Initial Conditions\"></Sample>")
  
  thickness <- xml_find_all(soilNode,  ".//Water/Thickness")[[1]]
  xml_add_child(ic, thickness)
  dlayer<- cumsum(as.numeric(unlist(as_list(thickness))))
  # NB. guessed distribution
  no3Fn<-approxfun(x = c(150, 300, 600, 900, 1200),
                   y = c(0.6, 0.2, 0.1, 0.1, 0.0), rule=2)
  no3<-read_xml("<NO3/>")
  for (l in dlayer) {
    # This may not be correct if layers are different FIXME
    xml_add_child(no3, read_xml(paste0("<double>", no3Fn(l) * getDef(site, "isn"), "</double>")))
  }
  xml_add_child(ic, no3)

  nh4<-read_xml("<NH4/>")
  for (l in dlayer) {
    xml_add_child(nh4, read_xml(paste0("<double>0</double>")))
  }
  xml_add_child(ic, nh4)

  isw<-read_xml("<SW/>")
  for (l in getDef(site, "isw")) {
    xml_add_child(isw, read_xml(paste0("<double>", l, "</double>")))
  }
  xml_add_child(ic, isw)
  xml_add_child(ic,read_xml("<NO3Units>kgha</NO3Units>"))
  xml_add_child(ic,read_xml("<NH4Units>kgha</NH4Units>"))
  xml_add_child(ic,read_xml("<SWUnits>Volumetric</SWUnits>"))
  xml_add_child(ic,read_xml("<OCUnits>Total</OCUnits>"))
  xml_add_child(ic,read_xml("<PHUnits>Water</PHUnits>"))
  return(ic)
}


# mash up the template into a single experiment simulation
doit<- function(parent, sim) {

  doc<-read_xml("base.apsim")
  simNode <- xml_find_all(doc, "//simulation")[[1]]
  xml_attr(simNode, "name") <- unique(sim$SimulationName)
  
  met <- xml_find_all(simNode, "//metfile")
  xmlSetText(met, "filename", getDef(unique(sim$site), "metfile"))
  
  patch <- getDef(unique(sim$site), "patchmetfile")
  if (length(patch) > 0) {
    xml_add_sibling(met, read_xml(paste0("<patchinput><filename>",patch, "</filename></patchinput>")))
  }
  dates<-range(sim$Clock.Today)
  clock <- xml_find_all(simNode, "//clock")
  
  # Clock starts day before the earliest TOS for this site. Important for SW initialisation
  xmlSetText(clock, "start_date", format.Date(getDef(unique(sim$site), "TOS1") - 1, format="%d/%m/%Y"))
  xmlSetText(clock, "end_date", format.Date(getDef(unique(sim$site), "TOS1") + 270, format="%d/%m/%Y"))
  
  # copy in a new soil 
  soil <- xml_find_all(simNode, "//Soil")
  xml_replace(soil, xml_find_all(soilDoc, 
       paste0(".//Soil[@name='", getDef(unique(sim$site), "Soil"), "']")))

  thisSoil <- xml_find_all(simNode, "//Soil")
  
  # Ensure lentil has a water node - it wont be in APSoil
  if (length(xml_find_all(thisSoil,  ".//SoilCrop[@name='lentil']")) == 0) {
    src <- xml_find_all(thisSoil,  ".//SoilCrop[@name='wheat']")
    if (length(src) == 0) {
      src <- xml_find_all(thisSoil,  ".//SoilCrop[@name='sorghum']")
      xml_add_sibling(src, src)
      src <- xml_find_all(thisSoil,  ".//SoilCrop[@name='sorghum']")[2]
    } else {
      xml_add_sibling(src, src)
      src <- xml_find_all(thisSoil,  ".//SoilCrop[@name='wheat']")[2]
    }
    xml_attr(src, "name") <- "lentil"
  }
  xml_add_child(thisSoil, doiISoil(unique(sim$site), thisSoil))
  
  # Now the manager - sowing & factor levels for reporting
  uiParms <- xml_find_all(simNode, "//manager/ui")
  xmlSetText(uiParms, "sow_date", format.Date(getDef(unique(sim$site), unique(sim$TOS)), format="%d/%m/%Y"))
  xmlSetText(uiParms, "reset_date", format.Date(getDef(unique(sim$site), "TOS1") - 1, format="%d/%m/%Y"))
  xmlSetText(uiParms, "lentil_cv", unique(na.omit(sim$Lentil.SowingData.Cultivar)))
  if (getPop(unique(sim$SimulationName)) == "") {
    xmlSetText(uiParms, "lentil_density", getDef(unique(sim$site), "sowing_density")) 
  } else {
    xmlSetText(uiParms, "lentil_density", getPop(unique(sim$SimulationName))) 
  }
  xmlSetText(uiParms, "soil", getDef(unique(sim$site), "Soil"))
  xmlSetText(uiParms, "site", unique(sim$site))
  xmlSetText(uiParms, "tos", unique(sim$TOS))
  
  # Irrigation schedule
  irrSched <- getDef(unique(sim$site), unique(sim$IRR))
  #cat(paste0(unique(sim$site), " irr = '", sim$IRR, "', sc=", length(irrSched), "\n"))
  if (!is.null(irrSched)) {
    prepareScript <-
      xml_find_all(simNode,
                   "//manager/script/event[text()='start_of_day']/../text")
    newtext <- xml_text(prepareScript)
    #if (unique(sim$IRR) == "Irr1") {cat("Boing\n")}
    for (date in names(irrSched)) {
      newtext <- paste (
        newtext,
        paste0("if (today = Date('", date, "')) then\n",
               irrSched[[date]], "\n",
               "endif\n"),
        sep = "\n"
      )
    }
    xml_text(prepareScript) <- newtext
  }
  xml_add_child(parent, simNode)
}


# 2001 experiments from DR
exps2 <- rbind(
  expand.grid(site=c("Horsham"), 
              cv= c("digger", "northfield", "nugget"), 
              TOS=c("TOS1","TOS2","TOS3","TOS4"), stringsAsFactors = F ),
  expand.grid(site=c("Beulah"), 
              cv= c("digger", "northfield", "nugget"), 
              TOS=c("TOS1","TOS2","TOS3"), stringsAsFactors = F  ),
  expand.grid(site=c("Birchip"), 
              cv= c("digger", "northfield", "nugget"), 
              TOS=c("TOS1","TOS2","TOS3"), stringsAsFactors = F  ))

defaults[["Horsham,TOS1"]] <- as.Date("1-Jan-2001", format="%d-%b-%Y") + 122
defaults[["Horsham,TOS2"]] <- as.Date("1-Jan-2001", format="%d-%b-%Y") + 153
defaults[["Horsham,TOS3"]] <- as.Date("1-Jan-2001", format="%d-%b-%Y") + 164
defaults[["Horsham,TOS4"]] <- as.Date("1-Jan-2001", format="%d-%b-%Y") + 185
defaults[["Horsham,row_spacing"]] <- 250 
defaults[["Horsham,sowing_density"]] <- 152 
defaults[["Horsham,Soil"]] <- "dooen"
defaults[["Horsham,isw"]] <- c( 0.157, 0.157, 0.207, 0.219, 0.247, 0.248, 0.282) # 5%
defaults[["Horsham,isn"]] <- 60
defaults[["Horsham,metfile"]] <- "horsham.met"

defaults[["Beulah,TOS1"]] <- as.Date("1-Jan-2001", format="%d-%b-%Y") + 129
defaults[["Beulah,TOS2"]] <- as.Date("1-Jan-2001", format="%d-%b-%Y") + 167
defaults[["Beulah,TOS3"]] <- as.Date("1-Jan-2001", format="%d-%b-%Y") + 192
defaults[["Beulah,row_spacing"]] <- 250 
defaults[["Beulah,sowing_density"]] <- 152 
defaults[["Beulah,Soil"]] <- "Beulah"
defaults[["Beulah,isw"]] <- c(0.173, 0.236, 0.237, 0.272, 0.298, 0.333, 0.333 ) # 10%
defaults[["Beulah,isn"]] <- 130
defaults[["Beulah,metfile"]] <- "beulah.met"

defaults[["Birchip,TOS1"]] <- as.Date("1-Jan-2001", format="%d-%b-%Y") + 129
defaults[["Birchip,TOS2"]] <- as.Date("1-Jan-2001", format="%d-%b-%Y") + 167
defaults[["Birchip,TOS3"]] <- as.Date("1-Jan-2001", format="%d-%b-%Y") + 192
defaults[["Birchip,row_spacing"]] <- 250 
defaults[["Birchip,sowing_density"]] <- 152 
defaults[["Birchip,Soil"]] <- "FSbirchip"
defaults[["Birchip,isw"]] <- c(0.146, 0.253, 0.317, 0.336, 0.380, 0.257, 0.291) # 10%
defaults[["Birchip,isn"]] <- 130
defaults[["Birchip,metfile"]] <- "birchip.met"

# Similar procedure to the last, but minor differences
doit2 <- function(parent, sim) {
  doc<-read_xml("base.apsim")
  simNode <- xml_find_all(doc, "//simulation")[[1]]
  xml_attr(simNode, "name") <-  paste(sim, collapse="_")
  
  met <- xml_find_all(simNode, "//metfile")
  xmlSetText(met, "filename", getDef(unique(sim$site), "metfile"))
  
  clock <- xml_find_all(simNode, "//clock")
  
  xmlSetText(clock, "start_date", format.Date(getDef(sim$site, "TOS1") - 1, format="%d/%m/%Y"))
  xmlSetText(clock, "end_date", format.Date(getDef(sim$site, "TOS1") + 270, format="%d/%m/%Y"))

  soil <- xml_find_all(simNode, "//Soil")
  xml_replace(soil, xml_find_all(soilDoc, 
                                 paste0(".//Soil[@name='", getDef(sim$site, "Soil"), "']")))
  
  thisSoil <- xml_find_all(simNode, "//Soil")
  # Ensure lentil has a water node
  if (length(xml_find_all(thisSoil,  ".//SoilCrop[@name='lentil']")) == 0) {
    src <- xml_find_all(thisSoil,  ".//SoilCrop[@name='wheat']")
    xml_add_sibling(src, src)
  
    src <- xml_find_all(thisSoil,  ".//SoilCrop[@name='wheat']")[2] 
    xml_attr(src, "name") <- "lentil"
  
    xml_add_child(thisSoil, doiISoil(sim$site, thisSoil))
  }
  
  uiParms <- xml_find_all(simNode, "//manager/ui")
  xmlSetText(uiParms, "sow_date", format.Date(getDef(sim$site, sim$TOS), format="%d/%m/%Y"))
  xmlSetText(uiParms, "reset_date", format.Date(getDef(sim$site, "TOS1") - 1, format="%d/%m/%Y"))
  xmlSetText(uiParms, "lentil_cv", unique(sim$cv))
  xmlSetText(uiParms, "lentil_density", getDef(sim$site, "sowing_density"))
  xmlSetText(uiParms, "soil", getDef(sim$site, "Soil"))
  xmlSetText(uiParms, "site", unique(sim$site))
  xmlSetText(uiParms, "tos", unique(sim$TOS))
  
  xml_add_child(parent, simNode)
}

# Create the output file
root <- xml_new_root( "folder" ) 
xml_attr(root, "version") <- 36
xml_attr(root, "name") <- "Simulations"

for (s in xml_find_all(baseDoc,  "//folder[@name='Plots']")) {
  xml_add_child(root, s) 
}

exps<- unique(harv$SimulationName)
for(exp in exps) {
  doit(root, harv[harv$SimulationName == exp,])
}

#for(iexp in 1: nrow(exps2)) {
#  doit2(root, exps2[iexp,])
#}

write_xml(root, "Lentil auto.apsim")

# Assemble observed data

# gatton fldas seems odd..
g<- harv[harv$site== "Gatton" & harv$Stage=="StartFlowering", c("SimulationName", "TOS", "Clock.Today")]
g$sowdate <-as.Date(ifelse(g$TOS=="TOS2", defaults[["Gatton,TOS2"]], defaults[["Gatton,TOS3"]]), origin = "1970-01-01")
g$flDAS <- as.numeric(g$Clock.Today - g$sowdate)

for (i in 1:nrow(g)) {
  harv$FloweringDAS[ harv$SimulationName == g$SimulationName[i]] <- g$flDAS[i]
}

out <- list()
for (sim in unique(harv$SimulationName)) {
  row<- list()
  for (v in c("site", "TOS", "Lentil.SowingData.Cultivar", 
              "FloweringDAS", "MaturityDAS", 
              "Lentil.AboveGround.Wt", "GrainWt", "LAImax", "branches/m2")) {
    row[[v]] <- unique(harv[harv$SimulationName == sim, v])
    stopifnot(length(row[[v]]) <= 1)
  }
  out[[sim]] <- cbind(SimulationName = sim, as.data.frame(row))
}
out<- bind_rows(out)
out<- out[!is.na(out$Lentil.SowingData.Cultivar),]

colnames(out)[which(names(out) == "Lentil.SowingData.Cultivar")] <- "cultivar"
colnames(out)[which(names(out) == "Lentil.AboveGround.Wt")] <- "biomass"
colnames(out)[which(names(out) == "LAImax")] <- "MaxLAI"
colnames(out)[which(names(out) == "GrainWt")] <- "yield"
colnames(out)[which(names(out) == "branches/m2")] <- "branches.m2"

out$FloweringDAS <- round(out$FloweringDAS, 0) 
out$MaturityDAS <- round(out$MaturityDAS, 0) 
out$biomass <- round(out$biomass * 10, 1) # gsm -> kg/ha
out$yield <- round(out$yield * 10, 1)

# fix multiple entries 
for (i in c("Dooen01TOS1CvDiggerIrr0", "Dooen01TOS1CvDiggerIrr1")) {
  out$MaxLAI[out$SimulationName == i & is.na(out$MaxLAI)] <- out$MaxLAI[out$SimulationName == i & !is.na(out$MaxLAI)]
  out <- out[- which(out$SimulationName == i & is.na(out$biomass)),]
}


capitalise <- function(x) {
  s <- strsplit(x, " ")[[1]]
  paste(toupper(substring(s, 1,1)), tolower(substring(s, 2)),
        sep="", collapse=" ")
}

#old<-read.csv("Lentil_2001.obs.csv", header=T, stringsAsFactors = F)
#old$FloweringDAS <- old$flowering_doy - old$sowing_doy
#old$MaturityDAS<-NA
#old$SimulationName <- paste(sapply(old$site, capitalise), sapply(old$cultivar, capitalise), old$TOS, sep="_")
#out <- out %>% bind_rows(old[,c("SimulationName", "site", "TOS", "cultivar", "FloweringDAS","MaturityDAS")])
write.csv(out, "Lentil auto observed.csv", row.names = F)

ts<- as.data.frame(ts)

for (layer in 1:10) {
  col <- paste0("esw(", layer, ")")
  ts[col] <- NA
}
ts$esw_100_600 <- NA
ts$esw_0_600 <- NA

layerfrac <- function (dlayer, layer, max_depth) {
  cum_depth <- sum(dlayer[1:layer])
  if (cum_depth < max_depth) {return(1.0)}
  if (cum_depth - dlayer[layer] < max_depth)
    return((max_depth - (cum_depth - dlayer[layer])) / dlayer[layer]);
  return (0.0);
}

toplayerfrac <- function (dlayer, layer, min_depth) {
  cum_depth <- sum(dlayer[1:layer])
  if (cum_depth <= min_depth) {return(0.0)}
  if (cum_depth - min_depth < dlayer[layer])
    return( (cum_depth - min_depth) / dlayer[layer]);
  return (1.0);
}


# find esw for each soil
for (site in unique(ts$site)) {
   soil <- xml_find_all(root, paste0("//manager[@name='Rules']/ui/site[text()='", site, "']/../../../../Soil"))[1]
   #dlayer <- as.numeric(sapply(xml_find_all(soil, "./Water/Thickness/double"), xml_text))
   #ll15 <-as.numeric(sapply(xml_find_all(soil, "./Water/LL15/double"), xml_text))
   dlayer <- as.numeric(sapply(xml_find_all(soil, "./Water/SoilCrop[@name='lentil']/Thickness/double"), xml_text))
   dlayer <- dlayer[1:min(length(dlayer), 10)]
   ll <- as.numeric(sapply(xml_find_all(soil, "./Water/SoilCrop[@name='lentil']/LL/double"), xml_text))
   ll <- ll[1:min(length(ll), 10)]
   # esw
   for (layer in 1:10) {
     sw <- as.vector(unlist(ts[paste0("Soil.SoilWater.SW(",layer,")")]))
     ts[ts$site== site, paste0("esw(", layer, ")")] <- pmax(sw[ts$site == site] - ll[layer], 0)
   }
   esw<-ts[ts$site == site, paste0("esw(", 1:length(dlayer), ")")]
   #0-600 and 100-600 esw
   bottomFrac <- sapply(1:length(dlayer),  function(x) {layerfrac(dlayer, x, 600)})
   
   ts$esw_0_600[ts$site == site] <- apply(esw, 1, function(esw_) {
     esw_[bottomFrac == 0] <- 0; 
     sum(esw_ * dlayer * bottomFrac)})
   topFrac <- sapply(1:length(dlayer),  function(x) {toplayerfrac(dlayer, x, 100)})
   ts$esw_100_600[ts$site == site] <- apply(esw, 1, 
                                          function(esw_) {esw_[topFrac == 0] <- 0; esw_[bottomFrac == 0] <- 0; 
                                                  return(sum(esw_ * dlayer * bottomFrac * topFrac ))})
}

# Assemble observed daily data
out<-ts[which(!is.na(ts$Lentil.SowingData.Cultivar)),
          c("SimulationName", "site", "TOS", "IRR", "Clock.Today", "DAS",  "Lentil.SowingData.Cultivar", 
            "LAI", "leaves/plant", 
            "Lentil.AboveGround.Wt", "GrainWt",
            "Soil.SoilWater.SW(1)","Soil.SoilWater.SW(2)","Soil.SoilWater.SW(3)",
            "Soil.SoilWater.SW(4)","Soil.SoilWater.SW(5)","Soil.SoilWater.SW(6)",
            "Soil.SoilWater.SW(7)", "esw(1)", "esw(2)", "esw(3)", "esw(4)", "esw(5)", "esw(6)", "esw(7)",
            "esw_0_600", "esw_100_600")]

colnames(out)[which(names(out) == "Clock.Today")] <- "Date"
colnames(out)[which(names(out) == "DAS")] <- "DaysAfterSowing"
colnames(out)[which(names(out) == "Lentil.SowingData.Cultivar")] <- "cultivar"
colnames(out)[which(names(out) == "Lentil.AboveGround.Wt")] <- "AboveGround.Wt"
colnames(out)[which(names(out) == "LAI")] <- "lai"
colnames(out)[which(names(out) == "Soil.SoilWater.SW(1)")] <- "sw(1)"
colnames(out)[which(names(out) == "Soil.SoilWater.SW(2)")] <- "sw(2)"
colnames(out)[which(names(out) == "Soil.SoilWater.SW(3)")] <- "sw(3)"
colnames(out)[which(names(out) == "Soil.SoilWater.SW(4)")] <- "sw(4)"
colnames(out)[which(names(out) == "Soil.SoilWater.SW(5)")] <- "sw(5)"
colnames(out)[which(names(out) == "Soil.SoilWater.SW(6)")] <- "sw(6)"
colnames(out)[which(names(out) == "Soil.SoilWater.SW(7)")] <- "sw(7)"

write.csv(out, "Lentil auto observed daily.csv", row.names = F)
