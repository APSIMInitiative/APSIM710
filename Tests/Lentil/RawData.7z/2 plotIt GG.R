rm(list=ls())
setwd("~/work/People/Daniel/2019 Lentils/New Trials/First Cut/")

# Greenethorpe & gatton

# Make some plots

library(dplyr)
library(data.table)
library(ggplot2)
library(gridExtra)
library(grid)

options(stringsAsFactors = F)

# Generic function to read apsim output files. Adds factor levels if found.
read.apsim <- function(apsim.name) {
  header<-readLines(apsim.name, n=25)
  if (length(header) == 0 ) {return(NULL)}
  i<-3  # 4th line
  apsim <- read.table(apsim.name,skip=i+1,na.strings=c("NA","?"))
  names(apsim) <- unlist(strsplit(trimws(header[i]), " +"))
  
#  cat(apsim.name, " = ", ncol(apsim), "\n")
  return(cbind(filename=apsim.name, apsim))
}

capitalise <- function(x) {
  s <- strsplit(x, " ")[[1]]
  paste(toupper(substring(s, 1,1)), tolower(substring(s, 2)),
        sep="", collapse=" ")
}

groups<- list()
groups[["early"]] <- c("HallmarkXT", "Bolt")
groups[["mid"]] <- c("Blitz", "Jumbo2", "Ace")
groups[["late"]] <- c("Nugget", "Digger", "Greenfield", "Northfield")

df.pred<- do.call(rbind, lapply(list.files(pattern="^.*Harvest\\.out$"), read.apsim))
df.pred$SimulationName<- tolower(sapply(strsplit(df.pred$filename, " "), function (x) {return(x[1])}))
df.pred$TOS <- toupper(df.pred$TOS)
df.pred$site <- sapply(df.pred$site, capitalise)
df.pred$cultivar <- sapply(df.pred$cultivar, capitalise)
df.pred<- df.pred[,c("SimulationName", "site", "TOS", "cultivar", "FloweringDAS", "MaturityDAS", "biomass", "yield", "MaxLAI")]

df.obs<-  read.csv("Lentil auto observed.csv")
df.obs$SimulationName<- tolower(df.obs$SimulationName)
df.obs$cultivar <- sapply(df.obs$cultivar, capitalise)
df.obs$site <- sapply(df.obs$site, capitalise)


pdf("plotIt GG.pdf", width = 7, height=6)

# merge in predicted 
df <- df.obs %>% 
  left_join(select(df.pred, -one_of( c("site", "TOS", "cultivar"))), 
                           by=c("SimulationName"), 
                           suffix = c(".obs", ".pred")) %>%
  subset(site == "Gatton" | site == "Greenethorpe2")


ggplot(df[!is.na(df$FloweringDAS.obs),]) + geom_point(aes(x=FloweringDAS.obs, y=FloweringDAS.pred, color=site)) + 
    scale_x_continuous(limits=range(na.omit(c(df$FloweringDAS.obs, df$FloweringDAS.pred)))) +
    scale_y_continuous(limits=range(na.omit(c(df$FloweringDAS.obs, df$FloweringDAS.pred)))) +
  labs(title="Flowering DAS", x="Observed", y = "Predicted") +
  geom_abline(intercept=0, colour="grey") + theme_minimal()

ggplot(df[!is.na(df$FloweringDAS.obs),]) + geom_point(aes(x=FloweringDAS.obs, y=FloweringDAS.pred, color=cultivar)) + 
  scale_x_continuous(limits=range(na.omit(c(df$FloweringDAS.obs, df$FloweringDAS.pred)))) +
  scale_y_continuous(limits=range(na.omit(c(df$FloweringDAS.obs, df$FloweringDAS.pred)))) +
  labs(title="Flowering DAS - Gatton & Greenethorpe", x="Observed", y = "Predicted") +
  geom_abline(intercept=0, colour="grey") + theme_minimal()

ggplot(df[!is.na(df$FloweringDAS.obs),]) + geom_point(aes(x=FloweringDAS.obs, y=FloweringDAS.pred, color=TOS)) + 
  scale_x_continuous(limits=range(na.omit(c(df$FloweringDAS.obs, df$FloweringDAS.pred)))) +
  scale_y_continuous(limits=range(na.omit(c(df$FloweringDAS.obs, df$FloweringDAS.pred)))) +
  labs(title="Flowering DAS", x="Observed", y = "Predicted") +
  geom_abline(intercept=0, colour="grey") +
  theme_minimal()


########### Timeseries data
df.pred<- rbindlist( lapply(list.files(pattern="^.*Daily\\.out$"), read.apsim), fill=T)
df.pred$SimulationName<- tolower(sapply(strsplit(df.pred$filename, " "), function (x) {return(x[1])}))
df.pred$TOS <- toupper(df.pred$TOS)
df.pred$site <- sapply(df.pred$site, capitalise)
df.pred$cultivar <- sapply(df.pred$cultivar, capitalise)
df.pred$Date <- as.Date(df.pred$Date, format="%d/%m/%Y")
colnames(df.pred)[which(names(df.pred) == "esw_0_600")] <-"esw(0-600)"
colnames(df.pred)[which(names(df.pred) == "esw_100_600")] <-"esw(100-600)"

df.pred$cvgroup <- ifelse(df.pred$cultivar %in% groups[["early"]], "Early",
                          ifelse(df.pred$cultivar %in% groups[["mid"]], "Mid",
                                 ifelse(df.pred$cultivar %in% groups[["late"]], "Late", NA)))


df.obs<-  read.csv("Lentil auto observed daily.csv")
df.obs$SimulationName<- tolower(df.obs$SimulationName)
df.obs$cultivar <- sapply(df.obs$cultivar, capitalise)
df.obs$site <- sapply(df.obs$site, capitalise)
df.obs$Date <- as.Date(df.obs$Date, format="%d/%m/%Y")
df.obs$cvgroup <- ifelse(df.obs$cultivar %in% groups[["early"]], "Early",
                         ifelse(df.obs$cultivar %in% groups[["mid"]], "Mid",
                                ifelse(df.obs$cultivar %in% groups[["late"]], "Late", NA)))


colnames(df.obs)[which(names(df.obs) == "sw.1.")] <-"sw(1)"
colnames(df.obs)[which(names(df.obs) == "sw.2.")] <-"sw(2)"
colnames(df.obs)[which(names(df.obs) == "sw.3.")] <-"sw(3)"
colnames(df.obs)[which(names(df.obs) == "sw.4.")] <-"sw(4)"
colnames(df.obs)[which(names(df.obs) == "sw.5.")] <-"sw(5)"
colnames(df.obs)[which(names(df.obs) == "sw.6.")] <-"sw(6)"
colnames(df.obs)[which(names(df.obs) == "sw.7.")] <-"sw(7)"

colnames(df.obs)[which(names(df.obs) == "esw.1.")] <-"esw(1)"
colnames(df.obs)[which(names(df.obs) == "esw.2.")] <-"esw(2)"
colnames(df.obs)[which(names(df.obs) == "esw.3.")] <-"esw(3)"
colnames(df.obs)[which(names(df.obs) == "esw.4.")] <-"esw(4)"
colnames(df.obs)[which(names(df.obs) == "esw.5.")] <-"esw(5)"
colnames(df.obs)[which(names(df.obs) == "esw.6.")] <-"esw(6)"
colnames(df.obs)[which(names(df.obs) == "esw.7.")] <-"esw(7)"

colnames(df.obs)[which(names(df.obs) == "esw_0_600")] <-"esw(0-600)"
colnames(df.obs)[which(names(df.obs) == "esw_100_600")] <-"esw(100-600)"


#table(df.obs$`sw(2)` > 0 , df.obs$site)

# merge together 
df <- df.pred %>% 
  left_join(select(df.obs, -one_of( c("site", "TOS", "cultivar", "cvgroup", "Date"))), 
            by=c("SimulationName", "DaysAfterSowing"), 
            suffix = c(".pred", ".obs")) %>%
  subset(site == "Gatton" | site == "Greenethorpe2")


ggplot(df) + 
  geom_point(aes(x=DaysAfterSowing, color=cvgroup, y=AboveGround.Wt.obs), na.rm=T)  + 
  geom_line(aes(x=DaysAfterSowing, group=SimulationName, color=cvgroup, y=AboveGround.Wt.pred))  +
  labs(y="Biomass Wt") +
  facet_wrap(~site)  + theme_minimal() + theme(legend.position = "none")

dev.off()