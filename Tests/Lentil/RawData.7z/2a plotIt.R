rm(list=ls())
setwd("~/work/Projects/GRDC Pulse 2019/Lentils/Second Cut/")

# Make some plots

library(dplyr)
library(ggplot2)
library(gridExtra)
library(grid)
library(officer)
library(rvg)
library(ggsci)

options(stringsAsFactors = F)

# Generic function to read apsim output files. Adds factor levels if found.
read.apsim <- function(apsim.name) {
  header<-readLines(apsim.name, n=25)
  if (length(header) == 0 ) {return(NULL)}
  i<-3  # 4th line
  apsim <- read.table(apsim.name,skip=i+1,na.strings=c("NA","?"))
  names(apsim) <- unlist(strsplit(trimws(header[i]), " +"))
  
#  cat(apsim.name, " = ", ncol(apsim), "\n")
  return(cbind(filename=apsim.name, apsim))
}

capitalise <- function(x) {
  s <- strsplit(x, " ")[[1]]
  paste(toupper(substring(s, 1,1)), tolower(substring(s, 2)),
        sep="", collapse=" ")
}

groups<- list()
groups[["early"]] <- c("HallmarkXT", "Bolt")
groups[["mid"]] <- c("Blitz", "Jumbo2", "Ace")
groups[["late"]] <- c("Nugget", "Digger", "Greenfield", "Northfield")

df.pred<- do.call(rbind, lapply(list.files(pattern="^.*Harvest\\.out$"), read.apsim))
df.pred$SimulationName<- tolower(sapply(strsplit(df.pred$filename, " "), function (x) {return(x[1])}))
df.pred$TOS <- toupper(df.pred$TOS)
df.pred$site <- sapply(df.pred$site, capitalise)
df.pred$cultivar <- sapply(df.pred$cultivar, capitalise)
df.pred$Irr <- ifelse(grepl("irr1", df.pred$SimulationName, fixed=T),  "irrigated", "rainfed")
df.pred<- df.pred[,c("SimulationName", "site", "TOS", "Irr","cultivar", "FloweringDAS", "MaturityDAS", "biomass", "yield", "MaxLAI")]

df.obs<-  read.csv("Lentil auto observed.csv")
df.obs$SimulationName<- tolower(df.obs$SimulationName)
df.obs$cultivar <- sapply(df.obs$cultivar, capitalise)
df.obs$site <- sapply(df.obs$site, capitalise)


#pdf("2a plotIt.pdf", width = 7, height=6)
doc <- read_pptx()

# merge in predicted 
df <- df.obs %>% left_join(df.pred[,!names(df.pred) %in% c("site", "TOS", "cultivar")], 
                           by=c("SimulationName"), 
                           suffix = c(".obs", ".pred"))

df$site[grepl("^Greeneth.*", df$site)] <- "Greenethorpe"
pal<-brewer.pal(n = length(unique(df$site)), name = 'Dark2')

g<-ggplot(df, aes(x=FloweringDAS.obs, y=FloweringDAS.pred)) + 
  geom_point(aes( color=site),size= 2.5,  na.rm = T) +
#  geom_smooth(method='lm', se=F, formula= y ~ x, color="black", size=0.5, na.rm = T) +
    scale_x_continuous(limits=range(na.omit(c(df$FloweringDAS.obs, df$FloweringDAS.pred)))) +
    scale_y_continuous(limits=range(na.omit(c(df$FloweringDAS.obs, df$FloweringDAS.pred)))) +
  labs(title="Flowering DAS", x="Observed", y = "Predicted", color="Site") +
  scale_color_d3() +
  geom_abline(intercept=0, colour="grey") + theme_minimal()

doc <- add_slide(doc, 'Title and Content', 'Office Theme')
doc <- ph_with(doc, dml(ggobj=g), ph_location(width=6,height=5))


# g<-ggplot(df, aes(x=FloweringDAS.obs, y=FloweringDAS.pred)) + 
#   geom_point(aes( color=cultivar), na.rm = T) + 
#   scale_x_continuous(limits=range(na.omit(c(df$FloweringDAS.obs, df$FloweringDAS.pred)))) +
#   scale_y_continuous(limits=range(na.omit(c(df$FloweringDAS.obs, df$FloweringDAS.pred)))) +
#   labs(title="Flowering DAS", x="Observed", y = "Predicted", color="Cultivar") +
#   geom_abline(intercept=0, colour="grey") +
#   theme_minimal()
# doc <- add_slide(doc, 'Title and Content', 'Office Theme')
# doc <- ph_with(doc, dml(ggobj=g), ph_location(width=6,height=5))
# 
# g<-ggplot(df, aes(x=FloweringDAS.obs, y=FloweringDAS.pred)) + 
#   geom_point(aes( color=TOS), na.rm = T) + 
#   scale_x_continuous(limits=range(na.omit(c(df$FloweringDAS.obs, df$FloweringDAS.pred)))) +
#   scale_y_continuous(limits=range(na.omit(c(df$FloweringDAS.obs, df$FloweringDAS.pred)))) +
#   labs(title="Flowering DAS", x="Observed", y = "Predicted", color="TOS") +
#   geom_abline(intercept=0, colour="grey") +
#   theme_minimal()
# doc <- add_slide(doc, 'Title and Content', 'Office Theme')
# doc <- ph_with(doc, dml(ggobj=g), ph_location(width=6,height=5))
# 
# g<-ggplot(df, aes(x=MaturityDAS.obs, y=MaturityDAS.pred)) +
#   geom_point(aes(color=cultivar),na.rm=T) + 
#   scale_x_continuous(limits=range(na.omit(c(df$MaturityDAS.obs, df$MaturityDAS.pred)))) +
#   scale_y_continuous(limits=range(na.omit(c(df$MaturityDAS.obs, df$MaturityDAS.pred)))) +
#   labs(title="Maturity DAS", x="Observed", y = "Predicted", color="Cultivar") +
#   geom_abline(intercept=0, colour="grey") +
#   theme_minimal()
# doc <- add_slide(doc, 'Title and Content', 'Office Theme')
# doc <- ph_with(doc, dml(ggobj=g), ph_location(width=6,height=5))
# 
# g<-ggplot(df, aes(x=MaturityDAS.obs, y=MaturityDAS.pred)) + 
#   geom_point(aes( color=site), na.rm=T) + 
#   scale_x_continuous(limits=range(na.omit(c(df$MaturityDAS.obs, df$MaturityDAS.pred)))) +
#   scale_y_continuous(limits=range(na.omit(c(df$MaturityDAS.obs, df$MaturityDAS.pred)))) +
#   labs(title="Maturity DAS", x="Observed", y = "Predicted") +
#   geom_abline(intercept=0, colour="grey") +
#   theme_minimal()
# doc <- add_slide(doc, 'Title and Content', 'Office Theme')
# doc <- ph_with(doc, dml(ggobj=g), ph_location(width=6,height=5))
# 
# ####
g<-ggplot(df,aes(x=biomass.obs, y=biomass.pred)) +
  geom_point(aes(color=site), size=2.5, na.rm=T) +
  scale_x_continuous(limits=range(na.omit(c(df$biomass.obs, df$biomass.pred)))) +
  scale_y_continuous(limits=range(na.omit(c(df$biomass.obs, df$biomass.pred)))) +
  labs(title="Biomass (kg/ha)", x="Observed", y = "Predicted", color="Site") +
  scale_color_d3() +
  geom_abline(intercept=0, colour="grey") +
  theme_minimal()
doc <- add_slide(doc, 'Title and Content', 'Office Theme')
doc <- ph_with(doc, dml(ggobj=g), ph_location(width=6,height=5))

# g<-ggplot(df,aes(x=biomass.obs, y=biomass.pred)) + 
#   geom_point(aes(color=site), na.rm=T) + 
#   scale_x_continuous(limits=range(na.omit(c(df$biomass.obs, df$biomass.pred)))) +
#   scale_y_continuous(limits=range(na.omit(c(df$biomass.obs, df$biomass.pred)))) +
#   labs(title="Biomass (kg/ha)", x="Observed", y = "Predicted", color="Site") +
#   geom_abline(intercept=0, colour="grey") + facet_wrap(~cultivar) +
#   theme_minimal()
# doc <- add_slide(doc, 'Title and Content', 'Office Theme')
# doc <- ph_with(doc, dml(ggobj=g), ph_location(width=6,height=5))
# 
# g<-ggplot(df, aes(x=biomass.obs, y=biomass.pred)) + 
#   geom_point(aes(color=cultivar), na.rm=T) + 
#   scale_x_continuous(limits=range(na.omit(c(df$biomass.obs, df$biomass.pred)))) +
#   scale_y_continuous(limits=range(na.omit(c(df$biomass.obs, df$biomass.pred)))) +
#   labs(title="Biomass (kg/ha)", x="Observed", y = "Predicted", color="Cultivar") +
#   geom_abline(intercept=0, colour="grey") + facet_wrap(~site) +
#   theme_minimal()
# doc <- add_slide(doc, 'Title and Content', 'Office Theme')
# doc <- ph_with(doc, dml(ggobj=g), ph_location(width=6,height=5))

# g<-ggplot(df,aes(x=biomass.obs, y=biomass.pred)) + geom_point(aes(color=TOS), na.rm=T) + 
#   scale_x_continuous(limits=range(na.omit(c(df$biomass.obs, df$biomass.pred)))) +
#   scale_y_continuous(limits=range(na.omit(c(df$biomass.obs, df$biomass.pred)))) +
#   labs(title="Biomass (kg/ha)", x="Observed", y = "Predicted", color="TOS") +
#   geom_abline(intercept=0, colour="grey") + 
#   theme_minimal()
# doc <- add_slide(doc, 'Title and Content', 'Office Theme')
# doc <- ph_with(doc, dml(ggobj=g), ph_location(width=6,height=5))

# g<-ggplot(df[df$site=="Greenethorpe1",], aes(x=biomass.obs, y=biomass.pred)) +
#   geom_point(aes(color=TOS, shape=Irr), size=3) + 
#   scale_x_continuous(limits=c(0,6000)) +
#   scale_y_continuous(limits=c(0,6000)) +
#   labs(title="Biomass (kg/ha)", x="Observed", y = "Predicted", color="Greenethorpe", shape="Water") +
#   geom_abline(intercept=0, colour="grey") + 
#   theme_minimal()
# doc <- add_slide(doc, 'Title and Content', 'Office Theme')
# doc <- ph_with(doc, dml(ggobj=g), ph_location(width=6,height=5))

g<-ggplot(df,aes(x=yield.obs, y=yield.pred)) + geom_point(aes(color=site), size=2.5, na.rm=T) + 
  scale_x_continuous(limits=range(na.omit(c(df$yield.obs, df$yield.pred)))) +
  scale_y_continuous(limits=range(na.omit(c(df$yield.obs, df$yield.pred)))) +
  labs(title="Yield (kg/ha)", x="Observed", y = "Predicted", color="Site") +
  scale_color_d3() +
  geom_abline(intercept=0, colour="grey")  +
  theme_minimal()
doc <- add_slide(doc, 'Title and Content', 'Office Theme')
doc <- ph_with(doc, dml(ggobj=g), ph_location(width=6,height=5))

# g<-ggplot(df,aes(x=yield.obs, y=yield.pred)) + geom_point(aes(color=site), na.rm=T) + 
#   scale_x_continuous(limits=range(na.omit(c(df$yield.obs, df$yield.pred)))) +
#   scale_y_continuous(limits=range(na.omit(c(df$yield.obs, df$yield.pred)))) +
#   labs(title="Yield (kg/ha)", x="Observed", y = "Predicted", color="Site") +
#   geom_abline(intercept=0, colour="grey") + facet_wrap(~cultivar) +
#   theme_minimal()
# doc <- add_slide(doc, 'Title and Content', 'Office Theme')
# doc <- ph_with(doc, dml(ggobj=g), ph_location(width=6,height=5))
# 
# g<-ggplot(df, aes(x=yield.obs, y=yield.pred)) + 
#   geom_point(aes( color=cultivar), na.rm=T) + 
#   scale_x_continuous(limits=range(na.omit(c(df$yield.obs, df$yield.pred)))) +
#   scale_y_continuous(limits=range(na.omit(c(df$yield.obs, df$yield.pred)))) +
#   labs(title="Yield (kg/ha)", x="Observed", y = "Predicted", color="Cultivar") +
#   geom_abline(intercept=0, colour="grey") + facet_wrap(~site) +
#   theme_minimal()
# doc <- add_slide(doc, 'Title and Content', 'Office Theme')
# doc <- ph_with(doc, dml(ggobj=g), ph_location(width=6,height=5))

# g<-ggplot(df,aes(x=yield.obs, y=yield.pred)) + 
#   geom_point(aes( color=TOS), na.rm=T) + 
#   scale_x_continuous(limits=range(na.omit(c(df$yield.obs, df$yield.pred)))) +
#   scale_y_continuous(limits=range(na.omit(c(df$yield.obs, df$yield.pred)))) +
#   labs(title="Yield (kg/ha)", x="Observed", y = "Predicted", color="TOS") +
#   geom_abline(intercept=0, colour="grey") + 
#   theme_minimal()
# doc <- add_slide(doc, 'Title and Content', 'Office Theme')
# doc <- ph_with(doc, dml(ggobj=g), ph_location(width=6,height=5))
# 
# g<-ggplot(df[df$site=="Greenethorpe",], aes(x=yield.obs, y=yield.pred)) + 
#   geom_point(aes(color=TOS, shape=Irr), size=3) + 
#   scale_x_continuous(limits=c(0,3000)) +
#   scale_y_continuous(limits=c(0,3000)) +
#   labs(title="Yield (kg/ha)", x="Observed", y = "Predicted", color="Greenethorpe", shape="Water") +
#   geom_abline(intercept=0, colour="grey") + 
#   theme_minimal()
# doc <- add_slide(doc, 'Title and Content', 'Office Theme')
# doc <- ph_with(doc, dml(ggobj=g), ph_location(width=6,height=5))
  
print(doc, target = '2a plot.pptx')
